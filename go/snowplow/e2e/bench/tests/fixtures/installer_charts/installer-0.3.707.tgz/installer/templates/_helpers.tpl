{{/*
  installer umbrella — helpers (adapted from krateo-openstack-blueprint osh.* helpers).
  Unlike openstack, each component pins its OWN chart version, so the served CRD
  apiVersion is derived per-component from that component's version.
*/}}

{{/* Served apiVersion for a component's generated CRD, from its version string.
     "0.22.2" -> "composition.krateo.io/v0-22-2" */}}
{{- define "inst.apiVersion" -}}
{{- $ver := index . 0 -}}
{{- printf "composition.krateo.io/v%s" ($ver | toString | replace "." "-") -}}
{{- end -}}

{{/* Image for the installer's own lifecycle hook Jobs (self-bootstrap waves + the pre/post-delete
     teardown/cleanup reapers). These hooks only ever run `kubectl` inside `/bin/sh` poll loops
     (no helm/jq/yq/kustomize), so they use the minimal official-family alpine/kubectl (~21MB
     compressed, busybox shell) instead of alpine/k8s (~250MB compressed / 822MB unpacked). The
     smaller pull keeps every hook Job inside its activeDeadlineSeconds on fresh multi-node clusters
     where the fat image previously blew the 300s self-register/self-instance budget (#66). Pinned to
     kubectl 1.36.x to match the installer's k8s>=1.36 floor (was 1.31, already skewed). Single source
     of truth: a pure template constant, NOT a values key, so it never has to be threaded through
     values.schema.json / the crdgen'd Installer CRD / the composition-mode CR (cf. #68). */}}
{{- define "inst.hookImage" -}}alpine/kubectl:1.36.3{{- end -}}

{{/* Optional CompositionDefinition spec.chart extras (registry-level): insecureSkipVerifyTLS
     and credentials, rendered ONLY when set so the chart spec stays minimal on public
     registries. arg: (list $). passwordRef.namespace defaults to the krateo namespace.
     Used by Pass A (definitions.yaml) and the self-bootstrap installer CD. */}}
{{/* Emit spec.chart extras (credentials + insecureSkipVerifyTLS) for a chart pull.
     args: (list $top $effectiveRepo) — $effectiveRepo is the OCI registry base the pull uses
     (a component's `default ociRepo $c.repo`, or ociRepo for the umbrella's own chart).

     Two modes, keyed on registryAuth.registries (see values.yaml / #23):
     - registries[] NON-EMPTY: registry-keyed. Emit ONLY the entry whose `repo` matches
       $effectiveRepo; a pull whose registry has no entry gets NO credentials, so a token is
       never presented to a registry it does not belong to. The global username/passwordRef are
       ignored in this mode.
     - registries[] EMPTY (default): legacy — the global registryAuth credentials apply to every
       pull when enabled (backward-compatible, unchanged).
     insecureSkipVerifyTLS: the global toggle applies to every pull; a matched registries[] entry
     may raise it for its own registry. */}}
{{- define "inst.chartExtras" -}}
{{- $top := index . 0 -}}
{{- $repo := index . 1 -}}
{{- $ra := $top.Values.registryAuth -}}
{{- $registries := $ra.registries | default list -}}
{{- $lines := list -}}
{{- $cred := dict -}}
{{- $hasCred := false -}}
{{- $insecure := $ra.insecureSkipVerifyTLS -}}
{{- if $registries -}}
{{- range $r := $registries -}}
{{- if eq ($r.repo | toString) ($repo | toString) -}}
{{- if $r.passwordRef -}}{{- $cred = $r -}}{{- $hasCred = true -}}{{- end -}}
{{- if $r.insecureSkipVerifyTLS -}}{{- $insecure = true -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- else if $ra.enabled -}}
{{- $cred = $ra -}}{{- $hasCred = true -}}
{{- end -}}
{{- if $insecure -}}
{{- $lines = append $lines "insecureSkipVerifyTLS: true" -}}
{{- end -}}
{{- if $hasCred -}}
{{- $ns := $cred.passwordRef.namespace | default $top.Values.namespaces.krateo -}}
{{- $lines = append $lines (printf "credentials:\n  username: %s\n  passwordRef:\n    name: %s\n    namespace: %s\n    key: %s" ($cred.username | quote) ($cred.passwordRef.name | quote) ($ns | quote) ($cred.passwordRef.key | quote)) -}}
{{- end -}}
{{- join "\n" $lines -}}
{{- end -}}

{{/* The name of the image-pull dockerconfigjson Secret the installer derives from registryAuth (see
     templates/imagepull-secret.yaml) and injects into the components that ship PRIVATE krateo-agentiko
     IMAGES (autopilot's repo-mcp-server, core-provider-agent's chart-gate, agentgateway-policies' cert-replay
     hop — see inst.privateImageComponents). registryAuth.imagePullSecretName
     overrides the default so a caller can point at a pre-existing dockerconfigjson Secret instead. arg: $top */}}
{{- define "inst.imagePullSecretName" -}}
{{- .Values.registryAuth.imagePullSecretName | default "krateo-registry-image-pull" -}}
{{- end -}}

{{/* SINGLE source of truth for the components that ship PRIVATE krateo-agentiko IMAGES and expose an
     imagePullSecrets knob their chart documents as "wired from registryAuth". `path` is the FULL (dot-free)
     location of that knob inside the component spec, INCLUDING the final key: the injection walks all but the
     last segment as nested maps and sets the last segment to the pull-secret list, so a knob at ANY depth works
     (mcpServers.repoSearch.imagePullSecrets, or the cert-replay hop's certReplayHop.image.pullSecrets). Shared by
     compositions.yaml (the injection target) and inst.imagePullAuths (which registries to derive image-pull
     creds for) so the two lists can never drift. Add a component here to wire its image pull. arg: $top */}}
{{- define "inst.privateImageComponents" -}}
components:
- name: repo-mcp-server
  path:
  - imagePullSecrets
- name: structure-graph-mcp-server
  path:
  - imagePullSecrets
- name: config-refs-mcp-server
  path:
  - imagePullSecrets
- name: core-provider-agent
  path:
  - mcpServers
  - chartGate
  - imagePullSecrets
- name: agentgateway-policies
  path:
  - certReplayHop
  - image
  - pullSecrets
- name: agentgateway-policies
  path:
  - uiTokenHop
  - image
  - pullSecrets
{{/* kagent's PER-USER tool server runs a private krateo-agentiko build (the token-leak fix). The
     path is the SIBLING key toolImagePullSecrets, and NOT the pullSecrets inside toolImage.

     THE CONCLUSION SURVIVES kagent 0.1.23 AND ITS REASON DOES NOT, which is why this is rewritten
     rather than left alone. Until 0.1.22 the argument was: toolImage's schema REQUIRED repository
     and digest, crdgen carries chart `required` into the composition CRD, and the injection below
     CREATES the parent object while setting only the leaf -- so aiming at toolImage would write it
     with neither required sibling and the apiserver would reject the Kagent CR.

     0.1.23 removes `digest` from values entirely: the digest now comes from the chart's own helper,
     so no stored value can override it. toolImage has NO `required` left, and the schema's ONLY
     `required` anywhere is perUserRbac.toolImagePullSecrets.items: [name]. The old argument is gone.

     AIMING INSIDE toolImage IS STILL REFUSED, by a different mechanism: toolImage keeps
     `additionalProperties: false` and its declared properties are exactly [pullPolicy, repository].
     `pullSecrets` is not among them, so the injection is refused at CHART LOAD rather than by the
     apiserver. Same outcome, earlier and louder.

     Measured on the PUBLISHED 0.1.23 schema, not taken from the release note. Only the UPSTREAM
     sub-chart tool path is public; this one needs the cred. */}}
- name: kagent
  path:
  - perUserRbac
  - toolImagePullSecrets
- name: alert-provider
  path:
  - imagePullSecrets
{{/* zendesk-kog's wrapper plugin runs a PRIVATE krateo-blueprints image. Its Deployment has no
     render guard, so it runs on every install of the component regardless of which Zendesk kinds
     are enabled -- the pull secret is mandatory, not conditional. This is the first entry on
     krateo-blueprints rather than krateo-agentiko; the dockerconfigjson auths map is host-keyed and
     both are ghcr.io, so they collapse into one host entry. */}}
- name: zendesk-kog
  path:
  - plugin
  - imagePullSecrets
{{- end -}}

{{/* inst.imagePullAuths — the image-pull credential REFERENCES for the private-image components, as a JSON
     array of {host, username, secretName, secretNamespace, secretKey}, deduped to ONE entry per distinct
     image-registry host (a dockerconfigjson auths map is host-keyed). The current pins put both private-image
     components on the same agentiko repo, so they collapse to a single host entry; if two private-image
     components were ever on different credentials at the SAME host, the last one iterated would win — add a
     per-component secret then. Selects each credential the SAME way inst.chartExtras selects the CHART-pull cred,
     so the token that pulls a private IMAGE is exactly the one that authorizes that component's registry:
       - registries[] NON-EMPTY: the entry whose `repo` matches the component's effective repo
         (default ociRepo $c.repo). A component whose registry has no entry contributes nothing, so a token
         is never presented to a registry it does not belong to — and a same-host collision is impossible
         because we key off each private-image component's OWN repo, not the raw registries[] list.
       - registries[] EMPTY: the global registryAuth credential (only when enabled), host taken from the
         component's own repo (correct even if the images ever move off ociRepo's host).
     Lookup-FREE (returns refs, not tokens) so it is cheap enough to double as the inst.imagePullOn predicate;
     imagepull-secret.yaml resolves the token Secret and assembles the dockerconfigjson. Empty output means
     nothing is derivable. arg: (list $top) */}}
{{- define "inst.imagePullAuths" -}}
{{- $top := index . 0 -}}
{{- $ra := $top.Values.registryAuth -}}
{{- $registries := $ra.registries | default list -}}
{{- $names := list -}}
{{- range (include "inst.privateImageComponents" $top | fromYaml).components -}}{{- $names = append $names .name -}}{{- end -}}
{{- $byHost := dict -}}
{{- range $c := (include "inst.componentsYaml" $top | fromYaml).components -}}
{{- if has $c.name $names -}}
{{- $repo := default $top.Values.ociRepo $c.repo -}}
{{- $host := regexReplaceAll "^oci://" ($repo | toString) "" | splitList "/" | first -}}
{{- $cred := dict -}}{{- $has := false -}}
{{- if $registries -}}
{{- range $r := $registries -}}
{{- if and (eq ($r.repo | toString) ($repo | toString)) $r.passwordRef -}}{{- $cred = $r -}}{{- $has = true -}}{{- end -}}
{{- end -}}
{{- else if and $ra.enabled $ra.passwordRef.name -}}
{{- $cred = $ra -}}{{- $has = true -}}
{{- end -}}
{{- if $has -}}
{{- $ns := $cred.passwordRef.namespace | default $top.Values.namespaces.krateo -}}
{{- $_ := set $byHost $host (dict "host" $host "username" $cred.username "secretName" $cred.passwordRef.name "secretNamespace" $ns "secretKey" $cred.passwordRef.key) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if $byHost -}}{{- values $byHost | toJson -}}{{- end -}}
{{- end -}}

{{/* Is registryAuth image-pull wiring active? The SINGLE predicate shared by the derived-Secret render
     (imagepull-secret.yaml) and the componentValues injection (compositions.yaml) so the two can never
     drift into a dangling reference. True when registryAuth is active (enabled, or registries[] set — which
     is self-contained like inst.chartExtras) AND either the caller supplied a pre-existing imagePullSecretName
     (BYO) OR inst.imagePullAuths resolves at least one derivable credential (global-mode passwordRef, or a
     registries[] entry matching a private-image component's registry). arg: $top */}}
{{- define "inst.imagePullOn" -}}
{{- $ra := .Values.registryAuth -}}
{{- $active := or $ra.enabled (gt (len ($ra.registries | default list)) 0) -}}
{{- if and $active $ra.imagePullSecretName -}}true
{{- else if ne (include "inst.imagePullAuths" (list .)) "" -}}true
{{- end -}}
{{- end -}}

{{/* Is a feature flag enabled? args: (list $ "featureName"); empty featureName => true.
     Final feature set: coreProvider (engine marker, gates nothing), coreAgents (base agent layer),
     portal (the non-agent platform: authn/snowplow/frontend/portal + portal-starter + the
     observability stack), oasgenProvider, specialistAgents, agentGateway. Every component gates
     on its flag. */}}
{{/* No feature is force-enabled: every component gates on its feature flag, so a minimal
     "agent-only" install (just the autopilot + installer-agent) can disable the platform and let
     the agent provision it later by editing the Installer CR. Defaults in values.yaml are all true,
     so a plain `helm install` still brings up the full platform. */}}
{{- define "inst.coreFeatures" -}}{{- end -}}
{{/*
inst.compEnabled — is this COMPONENT's feature gate on? args: (list $top $c)

`feature` OR ANY entry in `alsoFeatures`. Use this wherever a COMPONENT decides; use
inst.featureEnabled directly only for a literal feature name.

WHY `alsoFeatures` AND NOT A LIST IN `feature`. A component several features need is owned by none
of them: cloudnative-pg is Keycloak's database today and kagent's tomorrow. Gating it on `keycloak`
alone would mean enabling Keycloak to get a Postgres operator; moving it to a dedicated feature
alone would turn it OFF underneath the Keycloak already using it. So it names one and also-names
the other.

The shape matters and is not a style choice. `properties.components.items` feeds crdgen VERBATIM
and becomes the Installer CRD's structural schema, and self-bootstrap applies the fully rendered pin
list as spec.components[] against it. A `oneOf`/type-union on `feature` would therefore be a CRD
shape, and crdgen's primaryType() keeps only the FIRST type of a union — the documented
int-or-string trap — so `feature` would likely compile as `string` and the apiserver would reject
every pin list carrying an array. `alsoFeatures` is `array of string`, which this schema already
ships and installs (deps, requiresApiGroups, configKeys, readerGroups).

This answers only "may this component be enabled". What must be HEALTHY before it renders is
`deps`, which is separate and unaffected.
*/}}
{{- define "inst.compEnabled" -}}
{{- $top := index . 0 -}}{{- $c := index . 1 -}}
{{- $on := include "inst.featureEnabled" (list $top $c.feature) -}}
{{- if ne $on "true" -}}
{{- range $f := (default list $c.alsoFeatures) -}}
{{- if eq (include "inst.featureEnabled" (list $top $f)) "true" -}}{{- $on = "true" -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- $on -}}
{{- end -}}

{{- define "inst.featureEnabled" -}}
{{- $top := index . 0 -}}{{- $feat := index . 1 -}}
{{- if not $feat -}}true
{{- else if has $feat (splitList " " (include "inst.coreFeatures" .)) -}}true
{{- else if index $top.Values.features $feat -}}true{{- end -}}
{{- end -}}

{{/* inst.fillPath — set a nested key on a spec dict only if absent, creating intermediate maps.
     args: (dict "target" $spec "path" (list "a" "b") "value" X). Mutates `target`, renders
     nothing, so a componentValues override always wins over the injection. */}}
{{- define "inst.fillPath" -}}
{{- $m := .target -}}
{{- $path := .path -}}
{{- $value := .value -}}
{{- $leaf := last $path -}}
{{- range $seg := (initial $path) -}}
{{- $next := index $m $seg -}}
{{- if not (kindIs "map" $next) -}}
{{- $next = dict -}}
{{- $_ := set $m $seg $next -}}
{{- end -}}
{{- $m = $next -}}
{{- end -}}
{{- if not (hasKey $m $leaf) -}}{{- $_ := set $m $leaf $value -}}{{- end -}}
{{- end -}}

{{/* inst.forcePath — like inst.fillPath but ALWAYS overwrites the leaf, even if already present.
     args: same as inst.fillPath. Use only where a componentValues override cannot be trusted to
     mean what it says: a boolean whose own schema declares a default reads identically whether a
     user deliberately set it or a sibling override (e.g. cors.allowOrigins) merely dragged the
     rest of that object's schema defaults — including this leaf — into existence. Fill-if-absent
     silently loses that race, so the flag never leaves its schema default. */}}
{{- define "inst.forcePath" -}}
{{- $m := .target -}}
{{- $path := .path -}}
{{- $value := .value -}}
{{- $leaf := last $path -}}
{{- range $seg := (initial $path) -}}
{{- $next := index $m $seg -}}
{{- if not (kindIs "map" $next) -}}
{{- $next = dict -}}
{{- $_ := set $m $seg $next -}}
{{- end -}}
{{- $m = $next -}}
{{- end -}}
{{- $_ := set $m $leaf $value -}}
{{- end -}}

{{/* Does the component's generated CRD exist AND serve this component's version yet?
     args: (list "Kind" "version")
     Version-aware: core-provider derives the served apiVersion from the chart version
     ("0.1.1" -> "v0-1-1"). On a component version bump the Kind already exists but the
     new served version lags until core-provider regenerates the CRD; a typed lookup of
     the not-yet-served apiVersion is a HARD ERROR. Checking spec.versions[].served for
     the exact version makes both Pass B emission and readiness checks tolerate that
     transient (treat as "not ready yet") instead of failing the whole render. */}}
{{- define "inst.crdExists" -}}
{{- $kind := index . 0 -}}{{- $ver := index . 1 -}}{{- $allCRDs := index . 2 -}}
{{- $want := printf "v%s" ($ver | toString | replace "." "-") -}}
{{- $found := "" -}}
{{/* $allCRDs is the cluster's CRD list, looked up ONCE by the caller and threaded through here — see
     the head of definitions.yaml / compositions.yaml. Ranging it in-memory (instead of a fresh
     apiextensions LIST per call) turns the gating from O(components x all-CRDs LISTs) into a single
     LIST; on a full cluster (121 CRDs, 42 large widget schemas) that cut the umbrella render from ~55s
     (which blew the cdc<->chart-inspector timeout) to a few seconds (D9, 2026-07-08). */}}
{{- range $allCRDs -}}
{{- if and (eq .spec.group "composition.krateo.io") (eq .spec.names.kind $kind) -}}
{{- range .spec.versions -}}{{- if and (eq .name $want) .served -}}{{- $found = "true" -}}{{- end -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- $found -}}
{{- end -}}

{{/* Is a peer Composition Ready=True? args: (list $ "Kind" "name" "version")
     Guarded: a typed lookup of a Kind whose CRD is not yet registered is a HARD ERROR
     in chart-inspector (server-side), unlike client-side `helm template` which returns
     empty. So short-circuit via inst.crdExists (an apiextensions lookup, always valid)
     before doing the typed Composition lookup. */}}
{{/* inst.readyFromConditions — the ONE place this chart decides whether a dep counts as ready.
     args: (list <conditions list>). Returns "true" or "".

     Split out of inst.ready so it can be TESTED: inst.ready has to `lookup` the live object,
     and `helm template` disables lookup, so the decision was previously unverifiable except
     against a cluster. Shipping a gate nobody can exercise is how the version that only
     accepted "True" went unexamined for as long as it did.

     READY, or HONESTLY UNKNOWN. A dep satisfies this gate when Ready is True, OR when it is
     Unknown for the specific reason that the cdc evaluated NONE of its managed children
     (core-provider#165). Those are different claims and only the first means "healthy":
     ZeroEvidence means "we do not know", and a dependant must not be blocked forever on
     ignorance that is a steady state rather than a transient.

     ZeroEvidence DOES NOT MEAN "the composition has no children", and this comment used to
     imply that it did. Corrected 2026-11-04 against core-provider's source (childhealth.go:155):
     a composition that genuinely manages nothing takes the PRESENT-AND-EMPTY branch and reports
     Ready=True / reason=Available. It never reaches ZeroEvidence. So the justification for this
     arm is NOT "no children, nothing to converge to".

     ZeroEvidence is emitted for TWO different situations, and only one of them justifies this arm:

       1. status.managed was NEVER RECORDED (`!found`). A DEFECT -- core-provider#326: absent
          inventory means no drift is reported, so Observe says up-to-date, so Update never runs,
          and Update is the only writer of status.managed. Self-perpetuating.
       2. The children ARE recorded and NONE of them publish readiness this controller can read
          (unevaluated+unreadable == total, total > 0). Legitimate, permanent, #165's case: a
          blueprint whose children are all custom resources with vocabularies only their own
          authors know never becomes interpretable.

     THIS ARM IS RIGHT FOR (2) AND WRONG FOR (1), and (1) is live. Measured on 2026-11-04:
     krateo-057 has 7 of 85 compositions with no status.managed key at all, every one of them
     reporting Unknown/ZeroEvidence with a deployed helm release and digest != managedDigest --
     agentgateway-policies, observability-page, portal-agents, alerts-page, blueprints-page,
     builders-page, config-refs-mcp-server. krateo-demo has 0 of 43, with observability-page at
     the SAME chart version publishing 75 managed children there. So it is not the chart: those
     seven are passing this gate on the strength of a bug's output, and their dependants are being
     emitted on that basis.

     DELIBERATELY NOT CHANGED. Refusing ZeroEvidence today would gate real dependants -- the 8
     below -- on a condition no operator can clear, which is the same trap pointed the other way.
     The fix is a SECOND reason word so a consumer can tell (1) from (2), by exactly the argument
     that separated ChildrenForbidden from NotObserved. core-provider is taking that to Diego;
     when the word exists, meaning (1) must NOT pass and this arm keeps meaning (2) only.

     KEYED ON `reason`, NEVER ON MESSAGE TEXT. The caveat message is prose and will be
     reworded; a gate reading prose breaks silently when it is.

     AND NEVER ON `Unknown` ALONE. A genuinely converging child also reports Unknown, and
     that one MUST block — it is the transient this gate exists to wait for. Accepting bare
     Unknown would turn every mid-creation dep into "ready" and let dependants render against
     children that do not exist yet.

     WHY THE CONSUMER GOES FIRST. 8 components dep on model-configs (installer-agent,
     krateo-autopilot, incident-agent, authn-agent, snowplow-agent, frontend-agent,
     clickstack-agent, core-provider-agent), and model-configs is one of exactly two
     compositions on krateo-057 at 100% unevaluated children. So the moment the cdc starts
     emitting Unknown, those 8 are gated unless this already accepts it. Landing it first is
     a no-op until then: a reason nothing emits is never matched. */}}
{{- define "inst.readyFromConditions" -}}
{{- $conds := index . 0 -}}
{{- $r := "" -}}
{{/* SYNCED=TRUE IS REQUIRED TOO, and the reason is that the Ready REASON cannot carry it.
     A PAUSED composition reports Ready=True with reason ReconcilePaused and Synced=False: it was
     healthy when it was paused and nothing is maintaining that state now, so it must not satisfy a
     dependency gate -- a dependant would be emitted against a component that is not converging and
     will not.
     A reason-based rule CANNOT express this. unstructured-runtime declares two constants,
     ReasonReconcilePausedReady and ReasonReconcilePaused, whose string VALUE is the same
     "ReconcilePaused", written on Ready and on Synced respectively. So the reason is ambiguous by
     construction and distinguishing the two cases requires reading the condition TYPE anyway.
     Synced is the typed condition that says it once.
     BLAST RADIUS, measured across 166 live composition instances on three clusters before this
     changed: exactly ONE object is newly withheld -- acme-feedback-controller on 057, which is the
     paused one this exists to catch. The 9 Unknown/ZeroEvidence instances are unaffected because
     their Synced is already True, and the one False/Creating instance was already withheld. */}}
{{- $synced := "" -}}
{{- range $conds -}}
{{- if eq (.type | toString) "Synced" -}}
{{- if eq (.status | toString) "True" -}}{{- $synced = "true" -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- range $conds -}}
{{- if eq (.type | toString) "Ready" -}}
{{- $s := .status | toString -}}
{{- if eq $s "True" -}}{{- $r = "true" -}}
{{- else if and (eq $s "Unknown") (eq (.reason | toString) "ZeroEvidence") -}}{{- $r = "true" -}}
{{/* ChildrenForbidden (core-provider#318): the cdc's SA got a 403 reading a managed child, so it
     was PREVENTED from observing rather than having observed unhealth. Accepted for the same
     reason as ZeroEvidence and NOT for the reason NotObserved is refused: a 403 from the
     authorization layer is a STEADY STATE -- nothing becomes forbidden later the way something
     becomes observed later. It persists until an operator changes a Role, so blocking a
     dependant on it would block forever. NotObserved stays refused precisely because it is the
     transient kind: an attempt failed and the next may succeed.
     WITHOUT this arm the cost is NOT a fleet-wide outage -- compositions.yaml:124 renders on
     `depsReady OR compositionExists`, so every existing install is unaffected. The cost falls
     entirely on a FRESH install, where a dependant would never be emitted on any pass because
     the condition never clears on its own. That is why this is allowlisted rather than tolerated. */}}
{{- else if and (eq $s "Unknown") (eq (.reason | toString) "ChildrenForbidden") -}}{{- $r = "true" -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if ne $synced "true" -}}{{- $r = "" -}}{{- end -}}
{{- $r -}}
{{- end -}}

{{- define "inst.ready" -}}
{{- $top := index . 0 -}}{{- $kind := index . 1 -}}{{- $name := index . 2 -}}{{- $ver := index . 3 -}}{{- $allCRDs := index . 4 -}}
{{- $r := "" -}}
{{/* Ask at ANY SERVED tag, not at $ver (#477, the last pinned-version site). A dep may
     legitimately live at an older served tag across a bump -- inst.emitDecision keeps it there on
     purpose -- so a lookup keyed on the PINNED version misses an object that exists and reports a
     healthy dep as not-Ready. That is absorbed by the $exists escape for a dependant that already
     exists, so the cost is a FRESH dependant held back for the length of the bump rather than
     anything deleted. Still wrong, and the last place in the chart that derived a version instead
     of reading what the cluster serves. */}}
{{- $found := "" -}}
{{- range $t := splitList " " (include "inst.servedTags" (list $kind $allCRDs)) -}}
{{- if and (not $found) $t -}}
{{- $o := lookup (printf "composition.krateo.io/%s" $t) $kind $top.Values.namespaces.krateo $name -}}
{{- if $o -}}
{{- $found = "true" -}}
{{/* nil-guard: a freshly-created dep CR can exist with .status still nil (controller hasn't
     written it yet). $o.status.conditions would then panic ("nil pointer evaluating
     interface {}.conditions") and chart-inspector returns 500, wedging the umbrella mid-chain.
     Coalesce .status to an empty dict so a status-less dep cleanly reads as not-ready. */}}
{{- $st := $o.status | default dict -}}
{{- $r = include "inst.readyFromConditions" (list ($st.conditions | default list)) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $r -}}
{{- end -}}

{{/* Are all of a component's deps Ready? args: (list $ $deps $components) */}}
{{- define "inst.depsReady" -}}
{{- $top := index . 0 -}}{{- $deps := index . 1 -}}{{- $comps := index . 2 -}}{{- $allCRDs := index . 3 -}}
{{- $all := "true" -}}
{{- range $d := $deps -}}
  {{- $kind := "" -}}{{- $ver := "" -}}{{- $dcomp := dict -}}
  {{- range $c := $comps -}}{{- if eq $c.name $d -}}{{- $kind = $c.kind -}}{{- $ver = $c.version -}}{{- $dcomp = $c -}}{{- end -}}{{- end -}}
  {{- if eq (include "inst.compEnabled" (list $top $dcomp)) "true" -}}
  {{- if ne (include "inst.ready" (list $top $kind $d $ver $allCRDs)) "true" -}}{{- $all = "" -}}{{- end -}}
  {{- end -}}
{{- end -}}
{{- $all -}}
{{- end -}}

{{/* HARD-REQUIREMENT gate — args: (list (list "group.example.io" ...) $allCRDs)
     Returns "true" if EVERY listed API GROUP has at least one served CRD in the cluster, "" if any
     is missing. An empty or absent `requiresApiGroups:` is vacuously "true".

     WHY IT EXISTS (installer 0.3.474 broke krateo-demo). builder-gate was pinned `feature: portal`
     with `deps: [portal, kagent]`. On krateo-demo — portal ON, coreAgents OFF — it was emitted
     anyway and chart-inspector 500'd on every reconcile:
       no matches for kind "RemoteMCPServer" in version "kagent.dev/v1alpha2"
       ensure CRDs are installed first
     `deps` cannot prevent that: inst.depsReady SKIPS a dep whose own feature is disabled (the
     readiness check sits INSIDE `if inst.featureEnabled $dep.feature`). That is correct for an
     OPTIONAL dep but makes `deps` an ORDERING constraint and nothing more.

     WHY THE UNIT IS AN API GROUP AND NOT A COMPONENT NAME — measured, not assumed. The first draft
     of this gate required the NAMED COMPONENT's composition to be Ready. krateo-demo refutes that
     design: it runs `ingress: false`, so the installer's cert-manager component is absent, yet SIX
     cert-manager.io CRDs are served there from a hand-install, and clickhouse-operator and
     mongodb-operator (which render cert-manager.io objects) are both Ready=Available. A
     component-keyed requirement would have SUPPRESSED two working compositions. What a chart needs
     is the KIND to be renderable, and any provider of that group satisfies it — installer-managed
     or not. So this asks the cluster what is served, which is the question that actually decides
     whether chart-inspector can render.

     PASS B ONLY, deliberately. Pass A registers the CompositionDefinition, which makes core-provider
     pull the chart and run crdgen; it never renders the chart with values, so it cannot produce the
     500. Gating Pass A would also make CD emission lookup-dependent for all 67 components, changing
     bring-up ordering fleet-wide and narrowing check-feature-render.py, which covers the CD layer
     precisely because `helm template` disables lookup.

     NO DRAIN BRANCH, unlike feature-OFF. A feature going off is an orderly teardown, so
     inst.dependentsGone keeps the component alive until its dependents leave. A missing API group is
     not orderly: continuing to emit buys an endless chart-inspector 500 rather than a graceful
     drain, which is the failure this gate exists to stop. So it suppresses at once. */}}
{{- define "inst.requiresApiGroups" -}}
{{- $groups := index . 0 -}}{{- $allCRDs := index . 1 -}}
{{- $all := "true" -}}
{{- range $g := $groups -}}
  {{- $found := "" -}}
  {{- range $crd := $allCRDs -}}
    {{- if eq $crd.spec.group $g -}}
      {{- range $crd.spec.versions -}}{{- if .served -}}{{- $found = "true" -}}{{- end -}}{{- end -}}
    {{- end -}}
  {{- end -}}
  {{- if not $found -}}{{- $all = "" -}}{{- end -}}
{{- end -}}
{{- $all -}}
{{- end -}}

{{/* THE EMISSION DECISION, in ONE place. args: (list $ $component $components $allCRDs)
     Returns the apiVersion TAG to emit the component at, or "" to withhold it. Callers render iff
     the result is non-empty and MUST use the returned tag as the emitted apiVersion.

     It is one helper because it was three expressions. compositions.yaml held the live gate,
     withheld-components.yaml held a SECOND copy of it for reporting, and inst.withheldReason
     re-derived a third answer to explain the outcome. While every copy was keyed on the pinned
     version they agreed by accident. #477 changed the live gate to resolve the emit tag to one the
     cluster actually SERVES -- and the copies did not change, so at the bump instant the reporter
     now calls "withheld" the very component the gate emits. Two gates cannot be kept in step by
     care; the duplication is the defect. Hence: one decision, three readers.

     registerOnly (catalog) blueprints are excluded by the CALLER (they are registered but never
     auto-emitted), so this helper is never asked about them. */}}
{{- define "inst.emitDecision" -}}
{{- $top := index . 0 -}}{{- $c := index . 1 -}}{{- $comps := index . 2 -}}{{- $allCRDs := index . 3 -}}
{{- $emit := include "inst.emitTag" (list $top $c.kind $c.name $c.version $allCRDs) -}}
{{- if $emit -}}
{{- if eq (include "inst.compEnabled" (list $top $c)) "true" -}}
{{/* HARD API-group requirements are ANDed OUTSIDE the $exists escape on purpose: that escape rides
     out a momentary depsReady flap without pruning a live workload, but a missing API GROUP is not a
     flap -- chart-inspector cannot render the chart at all, so emitting anyway buys an endless 500. */}}
{{- if eq (include "inst.requiresApiGroups" (list $c.requiresApiGroups $allCRDs)) "true" -}}
{{- $deps := include "inst.depsReady" (list $top $c.deps $comps $allCRDs) -}}
{{- $exists := include "inst.compositionExistsAny" (list $top $c.kind $c.name $allCRDs $c.namespace) -}}
{{- if or (eq $deps "true") (eq $exists "true") -}}{{- $emit -}}{{- end -}}
{{- end -}}
{{- else -}}
{{/* feature OFF -> reverse-dependency DRAIN: keep emitting until every component that deps on this
     one is gone, so teardown is leaves-first and never deletes this component (or the CRDs its
     release ships) out from under a still-present dependent. */}}
{{- if ne (include "inst.dependentsGone" (list $top $c.name $comps $allCRDs)) "true" -}}{{- $emit -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/* Reverse-dependency TEARDOWN gate — the mirror of inst.depsReady. args: (list $ "componentName" $components)
     Returns "true" if NO still-present Composition depends on <componentName> (so it is safe to stop
     rendering it and let the cdc delete it). Returns "" while ANY dependent's Composition still exists,
     so a feature-disabled component stays RENDERED (alive) until its dependents drain. This makes teardown
     reverse-topological (leaves first): a component — and the CRDs its helm release ships — is never deleted
     out from under a still-present dependent, so there are no orphaned CRs, no helm release stuck
     "uninstalling", and no CompositionDefinition delete deadlock. Guarded by inst.crdExists before the typed
     lookup (an unserved Kind is a hard error in chart-inspector), exactly like inst.ready. */}}
{{- define "inst.dependentsGone" -}}
{{- $top := index . 0 -}}{{- $name := index . 1 -}}{{- $comps := index . 2 -}}{{- $allCRDs := index . 3 -}}
{{- $gone := "true" -}}
{{- $isAgent := "" -}}
{{- range $c := $comps -}}{{- if and (eq $c.name $name) $c.agent -}}{{- $isAgent = "true" -}}{{- end -}}{{- end -}}
{{- range $c := $comps -}}
  {{- if and (has $name ($c.deps | default list)) (not (and $c.orchestrator (eq $isAgent "true"))) -}}
    {{/* Ask about the dependent at the tag it is actually SERVED at, not at its pinned version
         (#477 follow-on). The pinned form was correct while a composition could only exist at its
         pinned GVK. inst.emitTag now deliberately keeps a live composition at an OLDER served tag
         across a bump, so a lookup at the PINNED version MISSES an object that exists, $gone stays
         "true", and the draining component is deleted WHILE A DEPENDENT IS STILL THERE -- the
         exact outcome this helper exists to prevent, reintroduced by the fix for the other one. */}}
    {{- if eq (include "inst.compositionExistsAny" (list $top $c.kind $c.name $allCRDs $c.namespace)) "true" -}}{{- $gone = "" -}}{{- end -}}
  {{- end -}}
{{- end -}}
{{- $gone -}}
{{- end -}}

{{/* Does a component's OWN Composition CR currently exist? args: (list $ "Kind" "name" "version")
     The typed lookup is safe because inst.emitTag only ever returns a SERVED tag (an unserved Kind
     is a hard error in chart-inspector), so no unserved GVK is ever looked up.
     Used by Pass A (definitions.yaml) to keep a CompositionDefinition registered while its component
     is still present/draining — so the generated CRD OUTLIVES the Composition it serves and is never
     GC'd out from under a still-draining component (the Pass-A counterpart to inst.dependentsGone). */}}
{{- define "inst.compositionExists" -}}
{{- $top := index . 0 -}}{{- $kind := index . 1 -}}{{- $name := index . 2 -}}{{- $ver := index . 3 -}}{{- $allCRDs := index . 4 -}}
{{- $ns := index . 5 -}}
{{/* Keyed on the tag the instance is actually SERVED at, not on $ver (#477 follow-on). This helper
     answers "is this component still present?" for definitions.yaml, which uses it to keep a
     CompositionDefinition REGISTERED while the component drains. A pinned-version lookup misses a
     live CR that inst.emitTag is holding at an older served tag, so the definition would be
     deregistered and the generated CRD GC'd out from under the live composition -- the orphaned-CR
     outcome this helper was added to prevent. */}}
{{- include "inst.compositionExistsAny" (list $top $kind $name $allCRDs $ns) -}}
{{- end -}}

{{/* External IP of a browser-facing component's LoadBalancer Service. args: (list $ "svcNameSubstring")
     The component's underlying Service is named after its Helm release (e.g. authn-<hash>), so we
     match on a stable substring and return the assigned ingress IP — "" until the cloud LB is ready.
     This is the reconcile-time resolution the values.yaml exposure model documents: each reconcile
     re-runs the lookup, so the frontend config fills in as soon as the peer IPs are assigned. */}}
{{- define "inst.lbip" -}}
{{- $top := index . 0 -}}{{- $sub := index . 1 -}}{{- $ip := "" -}}
{{- range (lookup "v1" "Service" $top.Values.namespaces.krateo "").items -}}
{{- if and (eq (.spec.type | toString) "LoadBalancer") (contains $sub .metadata.name) -}}
{{- $lb := (.status | default dict).loadBalancer | default dict -}}
{{- range ($lb.ingress | default list) -}}{{- if .ip -}}{{- $ip = .ip -}}{{- end -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- $ip -}}
{{- end -}}

{{/*
inst.nodeip — a browser-reachable Node IP for NodePort exposure. Prefers an ExternalIP
(public), else falls back to the first InternalIP. "" if the cluster advertises neither (the
caller then omits the key and the next reconcile retries). */}}
{{- /* inst.nodeip — the browser-reachable node IP for NodePort exposure, read from the
       `krateo-nodeip` ConfigMap that the bootstrap resolves once (see self-bootstrap.yaml). We read
       a NAMESPACE ConfigMap here rather than a cluster `lookup "v1" "Node"` on purpose: the umbrella
       is rendered by the per-version `installers-v<ver>` render SA, and a cluster Node list needs a
       cluster grant that every version migration's FRESH SA lacks (wedging the render with
       `nodes is forbidden`). A namespace ConfigMap is always readable by that SA, so the node IP
       survives version migrations with no per-version cluster RBAC. Returns "" if the ConfigMap is
       absent (older bootstrap / not yet resolved) — the caller then omits the key and the next
       reconcile fills it, same graceful-degradation as the pending-LB path. */}}
{{- define "inst.nodeip" -}}
{{- $top := index . 0 -}}
{{- $cm := lookup "v1" "ConfigMap" $top.Values.namespaces.krateo "krateo-nodeip" -}}
{{- $data := (($cm | default dict).data | default dict) -}}
{{- $ext := $data.externalIP | default "" -}}
{{- $int := $data.internalIP | default "" -}}
{{- if $ext -}}{{ $ext }}{{- else -}}{{ $int }}{{- end -}}
{{- end -}}

{{/*
inst.peerurl — a peer component's BROWSER-reachable base URL, resolved from its Service per the
exposure model (values.yaml `exposure.type`), so a consumer's spec.config.<KEY> points at an
address the browser can actually reach — for LoadBalancer AND NodePort alike:
  - LoadBalancer -> http://<lb-ingress-ip|hostname>:<eport>  (eport = shared exposure.port, passed in)
  - NodePort     -> http://<node-ip>:<nodePort>              (nodePort read off the Service)
The Service is matched on a stable name substring ($svcMatch), narrowed to the exposed type.
Returns "" until the external address exists (LB IP still pending / no node IP) — the caller omits
the key so the frontend keeps its default and the next reconcile fills it. A STATIC operator
override (a real external hostname) is handled by the caller and wins over this; this helper only
covers the two auto-exposed modes. */}}
{{- define "inst.peerurl" -}}
{{- $top := index . 0 -}}{{- $sub := index . 1 -}}{{- $eport := index . 2 -}}{{- $url := "" -}}
{{- range (lookup "v1" "Service" $top.Values.namespaces.krateo "").items -}}
{{- if contains $sub .metadata.name -}}
{{- $t := .spec.type | toString -}}
{{- if eq $t "LoadBalancer" -}}
{{- $lb := (.status | default dict).loadBalancer | default dict -}}
{{- range ($lb.ingress | default list) -}}
{{- $addr := .ip | default .hostname -}}
{{- if $addr -}}{{- $url = printf "http://%s:%v" $addr $eport -}}{{- end -}}
{{- end -}}
{{- else if eq $t "NodePort" -}}
{{- $np := "" -}}
{{- range .spec.ports -}}{{- if .nodePort -}}{{- $np = .nodePort -}}{{- end -}}{{- end -}}
{{- $nip := include "inst.nodeip" (list $top) -}}
{{- if and $nip $np -}}{{- $url = printf "http://%s:%v" $nip $np -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $url -}}
{{- end -}}

{{/* inst.hostname — the external hostname for an exposed component under exposure.type=Gateway.
     args: (list $top $component). Returns exposure.hosts[<component-name>] if set, else the
     derived <svcMatch>.<baseDomain> when baseDomain is set, else "" (route/URL omitted). */}}
{{- define "inst.hostname" -}}
{{- $top := index . 0 -}}{{- $c := index . 1 -}}
{{- $override := index ($top.Values.exposure.hosts | default dict) $c.name -}}
{{- if $override -}}{{- $override -}}
{{- else if $top.Values.exposure.baseDomain -}}{{- printf "%s.%s" ($c.svcMatch | default $c.name) $top.Values.exposure.baseDomain -}}
{{- end -}}
{{- end -}}

{{/* inst.svcname — the EXACT name of the live Service backing a peer, for an HTTPRoute backendRef.
     args: (list $top $svcMatch). Prefers an exact name match, else the first contains-match
     (mirrors inst.peerurl). "" until the Service exists (route emitted next reconcile). Needs the
     services read the chart already grants the cdc SA (installers-lbip-services, self-bootstrap.yaml). */}}
{{- define "inst.svcname" -}}
{{- $top := index . 0 -}}{{- $sub := index . 1 -}}{{- $exact := "" -}}{{- $contains := "" -}}
{{- range (lookup "v1" "Service" $top.Values.namespaces.krateo "").items -}}
{{- if eq .metadata.name $sub -}}{{- $exact = .metadata.name -}}
{{- else if and (not $contains) (contains $sub .metadata.name) -}}{{- $contains = .metadata.name -}}{{- end -}}
{{- end -}}
{{- $exact | default $contains -}}
{{- end -}}

{{/*
inst.componentsYaml — the chart-managed component pin list, sourced from
files/component-pins.yaml (NOT .Values), so it is CHART CONTENT immune to
`helm upgrade --reuse-values`. A chart bump therefore always propagates its component
version/repo/dep pins on upgrade. Callers pass the ROOT context ($) so .Files is available and
parse the result:
    {{- $components := (include "inst.componentsYaml" $ | fromYaml).components -}}

PERMIT UPDATE — per-component `version` override from the Installer CR:
Each component's `version` may be overridden by the Installer CR's spec.components[].version
(= .Values.components here), matched by name. This lets an operator bump a live component version
by patching the Installer CR — the override flows through BOTH Pass A (definitions.yaml ->
CompositionDefinition spec.chart.version) AND Pass B (compositions.yaml -> the instance apiVersion
via inst.apiVersion), so the CD and its composition instance move in LOCKSTEP (no served-version
skew). When the CR does not set a component's version, the baked file version is used — so a chart
bump still propagates its pins and the set stays immune to `--reuse-values`. Only `version` is
overridable; all other pin fields (kind/chart/deps/tier/feature/exposure) remain chart content.
*/}}
{{- define "inst.componentsYaml" -}}
{{/* READS THE GENERATED DATA-ONLY COPY, NOT THE ANNOTATED ONE. files/component-pins.yaml is
     97.6% comment prose (722,800 of 740,859 bytes) and is .helmignore'd, because helm embeds the
     whole chart in its release record and a release Secret's data may not exceed 1 MiB DECODED.
     krateo-057 hit that: revision 546 sat at 1,047,684 bytes, 892 from the ceiling, and 547 was
     refused with `Secret "sh.helm.release.v1.installer.v547" is invalid: data: Too long`.
     Excluding the annotated file takes the archive from 519,968 to 246,583 bytes (-52.6%).
     THE TRAP THIS CREATES, and why check-pins-min-in-sync exists: edit a pin in the annotated
     file, forget to regenerate this one, and the chart silently renders the OLD pin while the
     repo shows the new one. That gate is a hard failure for exactly that case.
     Regenerate with: python3 hack/strip-pin-comments.py chart/files/component-pins.yaml \
                        -o chart/files/component-pins.min.yaml */}}
{{- $file := .Files.Get "files/component-pins.min.yaml" | fromYaml -}}
{{- $components := ($file.components | default list) -}}
{{/* Index the chart-pinned component names. */}}
{{- $known := dict -}}
{{- range $c := $components -}}{{- $_ := set $known (toString $c.name) true -}}{{- end -}}
{{/* RETIRED-NAMES allowlist (files/retired-components.yaml, installer#144 Landmine 1):
     a live Installer CR ships its FULL spec.components list wholesale on every upgrade
     (self-bootstrap.yaml), so a name whose pin was DELETED when its feature was retired
     still arrives here via .Values.components for at least one more reconcile. Such a
     name is neither pinned nor a legitimate append — index it so the append branch below
     can SKIP it (not fatal, not registered) while the typo-guard stays intact for every
     truly-unknown name. Future retirements just append the name to that file. */}}
{{- $retiredFile := .Files.Get "files/retired-components.yaml" | fromYaml -}}
{{- $retired := dict -}}
{{- range $n := ($retiredFile.retired | default list) -}}{{- $_ := set $retired (toString $n) true -}}{{- end -}}
{{/* .Values.components entries do one of two things, matched by name:
       - name IS a pinned component  -> override the whitelisted fields version / registerOnly / tier
         on that live component. `version` bumps its chart; `registerOnly: true` demotes it to
         registered-but-not-installed (Pass A registers the CD, Pass B suppresses the Composition) —
         the way a nested/multi-tenant child opts OUT of a pinned component it should not run (e.g.
         otel-collector-daemonset, whose node-level telemetry + hostPorts don't belong in a child on
         shared nodes; installer#38). `tier` re-groups it (e.g. -> catalog). `repo`/`chart` re-source it
         (see below). kind/deps stay NOT overridable (they'd break resolution). Footgun: do NOT registerOnly a component that
         others `deps` on — its dependents then never see it Ready and stall.
       `repo` (and `chart`, the artifact name in the URL) re-SOURCE the component (installer#84: let a
       user pull a component from a different registry — e.g. Docker Hub vs ghcr — so the source need not
       be equal for all). Safe to override because they change only WHERE/WHAT-PATH the chart is pulled
       from, not the component's identity (kind/deps stay; the CompositionDefinition/Composition name stays
       the component name), and `repo` threads through everywhere the effective repo is read: the CD chart
       URL (definitions.yaml), the chart-pull credentials (inst.chartExtras matches registries[] by repo),
       and the derived image-pull secret (inst.imagePullAuths). A PRIVATE override source needs a matching
       registryAuth.registries[] entry (repo == the override) for its pull credential; a public one needs
       nothing. IMPORTANT: use registries[] mode for a re-source to a DIFFERENT registry — in GLOBAL mode
       (registries[] empty, enabled) the single credential is presented to EVERY pull, so it would hand
       your ociRepo token to the override registry (fine when both are the same host with a cross-org
       token, e.g. ghcr; wrong for a genuinely different registry). `kind`/`deps` stay NOT overridable
       (those WOULD break resolution/identity — the CRD kind is crdgen'd from the chart at build time, so
       the override target must host the SAME chart+version the pin names, or Pass B never sees it Ready).
       - name is NOT pinned          -> APPEND it as a new component. This is how a CMP (tier-b)
         adds catalog blueprints (registerOnly + tier: catalog, e.g. openstack) via values while
         the base installer stays use-case-agnostic — it ships no such blueprint by default. */}}
{{- $ov := dict -}}
{{- $extra := list -}}
{{- range $o := (.Values.components | default list) -}}
{{- if and (kindIs "map" $o) (hasKey $o "name") -}}
{{- if hasKey $known (toString $o.name) -}}
{{/* PIN-OWNED KEYS ON A PINNED COMPONENT ARE IGNORED HERE, not refused, and not merged.
     `namespace` and `readerGroups` are decided by the pins file. This branch handles
     .Values.components, which is the OVERRIDE layer -- and because the self-bootstrap writes the
     EFFECTIVE components list into the Installer CR, and the CR's spec.components arrives here as
     .Values.components on the next render, a pin-owned key reaches this branch BY DESIGN one pass
     after any chart that sets it. It is not an operator's override at all; it is the chart's own
     value coming home.

     WHY NOT `fail`, which is what this did until 2026-11-18. A fail here does not reject a bad
     input -- it FREEZES THE CLUSTER. Measured on krateo-057 at 00:15:30Z rolling 0.3.674: the
     bootstrap post-upgrade hook patched the CR with the new pins (kyverno gained
     namespace: kyverno, a value present only in 0.3.674), THEN chart-inspector rendered and hit
     this fail, answering HTTP 500. ChartRenderable went False/InspectorUnavailable, RBACComplete
     Unknown/NotEvaluated, and no configuration change could apply. 96 releases stayed deployed and
     158 deployments stayed ready -- frozen, not damaged -- but `helm rollback` could NOT clear it,
     because the value was in the CR by then and EVERY chart carrying the fail refuses it. Only a
     hand edit of the CR unfroze it.

     WHY NOT COMPARE AGAINST THE PIN, which was my first fix. The acmp session found the flaw: an
     echo passes only while the pin and the CR AGREE, so the day the pins file CHANGES a namespace,
     every cluster's CR still holds the previous echo -- now a "different" value -- and every
     cluster freezes again, with the same unclearable rollback. That turns the guard into a trap
     for the pins file's own changes, which is worse than the bug it fixes.

     THE PROPERTY IS STILL HELD, and held more strongly than by refusing. The pins file is the ONLY
     source of a pinned component's namespace: this branch copies `namespace` into neither $fields
     nor the override map, so whatever the CR says is discarded and the pin always wins. A cluster
     therefore CANNOT decide a component lives somewhere else -- an attempt is inert rather than
     fatal, which is the same guarantee without a cluster-wide outage as its enforcement mechanism.
     And it is not silent: withheld-components.yaml reports what was not emitted, and the write-back
     no longer carries these keys at all (see inst.componentsPatchList).

     An APPENDED registerOnly blueprint is unaffected -- it takes the else branch below, where
     namespace/readerGroups are passed through whole, because for those the CR IS the only source. */}}{{- $fields := dict -}}
{{- range $k := (list "version" "registerOnly" "tier" "repo" "chart") -}}
{{- if hasKey $o $k -}}{{- $_ := set $fields $k (index $o $k) -}}{{- end -}}
{{- end -}}
{{- $_ := set $ov (toString $o.name) $fields -}}
{{- else if hasKey $retired (toString $o.name) -}}
{{/* RETIRED name (files/retired-components.yaml): its pin was deleted when its feature was
     retired, but the live CR's wholesale spec.components still carries it. SKIP it — do not
     append it (no dead CompositionDefinition) and do not fail (that would abort the whole
     umbrella render on every existing install, installer#144 Landmine 1). Deliberately NOT
     an `else` fallthrough: a retired name must be an explicit allowlist entry, never silence
     for any unpinned name. */}}
{{- else -}}
{{/* Unknown name = a CMP-appended catalog blueprint. Guard the footgun: a typo'd known-component
     name (e.g. `snowplowe`) would otherwise silently register a dead CompositionDefinition whose
     chart URL resolves to nothing. Only allow the append when the entry explicitly opts in as a
     registerOnly catalog blueprint — anything else is a mistake, so fail loudly at render time.
     (Retired names are handled by the branch above; a name that is neither pinned nor retired
     still fails here, preserving the typo-guard.) */}}
{{- if not $o.registerOnly -}}{{- fail (printf "components[%s]: unknown name not in files/component-pins.yaml — only registerOnly catalog blueprints may be appended via .Values.components (typo?)" (toString $o.name)) -}}{{- end -}}
{{/* An APPEND registers a brand-new CD, so it needs kind + version (the schema now requires only
     `name`, to let overrides of PINNED components omit them — installer#38). Guard here so an
     append missing them fails loudly instead of registering a broken CompositionDefinition. */}}
{{- if or (not (hasKey $o "kind")) (not (hasKey $o "version")) -}}{{- fail (printf "components[%s]: an appended catalog blueprint needs `kind` and `version` (only overrides of PINNED components may omit them)" (toString $o.name)) -}}{{- end -}}
{{- $extra = append $extra $o -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- range $c := $components -}}
{{- if hasKey $ov (toString $c.name) -}}
{{- range $k, $v := (index $ov (toString $c.name)) -}}
{{- $_ := set $c $k $v -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{ dict "components" (concat $components $extra) | toYaml }}
{{- end -}}

{{/* ---------------------------------------------------------------------------------------
     inst.jwtSigningKeyPEM — resolve the authn RS256 JWT signing key.

     TAKES THE LOOKED-UP SECRET AS A PARAMETER AND DOES NOT CALL `lookup` ITSELF. That is the
     whole point of it existing: `helm template` DISABLES lookup, so while the reuse/generate
     decision sat inline in secret.yaml next to its own `lookup` call, only ONE of its two arms
     could ever be rendered — the generate arm, because lookup always came back empty. The arm
     that matters could not be exercised without a cluster, and the arm that runs on a cluster
     was the untested one.

     WHY THE UNTESTED ARM IS THE DANGEROUS ONE. This key signs every JWT authn issues. If the
     reuse arm ever fails to fire — a lookup that returns empty on a cluster where the Secret
     exists, a renamed data key, a nil-map guard that stops matching — the else-arm generates a
     NEW key, helm applies it, authn restarts with it, and EVERY OUTSTANDING TOKEN BECOMES
     INVALID. There is no error anywhere: the render succeeds, the Secret applies cleanly, and
     the only symptom is that every signed-in user is logged out at once and no log says why.
     Rotation is indistinguishable from correct operation in every signal the chart produces.

     So the decision is split out here where .github/scripts/check-signing-key.py can hand it
     both a found Secret and nothing at all, assert the two differ, and assert the found case
     returns THAT key rather than a fresh one. secret.yaml keeps the `lookup` and passes its
     result in; the gate asserts that wiring textually, since it cannot execute it.
     --------------------------------------------------------------------------------------- */}}
{{- define "inst.jwtSigningKeyPEM" -}}
{{- $found := index . 0 -}}
{{- if and $found $found.data (hasKey $found.data "private.pem") -}}
{{- index $found.data "private.pem" | b64dec -}}
{{- else -}}
{{- genPrivateKey "rsa" -}}
{{- end -}}
{{- end -}}

{{/* ---------------------------------------------------------------------------------------
     inst.authnSigningKeySecretName / inst.authnSigningKeyKid — the NAME and the KID of authn's
     JWT signing key, both derived from ONE integer: authn.jwt.keyGeneration.

     WHY A GENERATION COUNTER AND NOT A NAME. authn has no per-token revocation, so the only
     lever against a leaked token is to stop serving the key that signed it. That means a NEW
     key, which means a new Secret, which means a new kid — because a validator caches JWKS by
     kid, and reusing the kid for different key material is the one combination that fails
     silently in both directions (a stale cache accepts tokens signed by the dead key; a fresh
     cache rejects tokens the dead key signed, with no way to tell which happened).

     Deriving BOTH from one counter is the point. Three facts have to agree — the Secret the
     umbrella creates, the Secret name authn mounts, and the kid authn advertises. Exposed as
     three values they can disagree, and every disagreement is quiet: mount the wrong Secret and
     authn signs with a key whose public half is not in its own JWKS, so every token it issues
     is rejected by every verifier, while authn itself logs a clean boot.

     GENERATION 1 IS THE IDENTITY CASE, deliberately. It returns authn's own chart defaults
     (`authn-jwt-signing-key`, `krateo-authn-key-1`, read from authn 0.40.0 values.yaml), so
     every existing cluster renders byte-identical objects and no upgrade rotates anything. A
     rotation is only ever an explicit bump of the counter.

     NEITHER CALLS `lookup`, for the same reason inst.jwtSigningKeyPEM does not: `helm template`
     disables lookup, so anything downstream of it is unreachable in CI. These are pure
     functions of the counter and .github/scripts/check-signing-key.py renders them directly.
     --------------------------------------------------------------------------------------- */}}
{{- define "inst.authnSigningKeySecretName" -}}
{{- $gen := index . 0 | default 1 | int -}}
{{- if le $gen 1 -}}authn-jwt-signing-key{{- else -}}authn-jwt-signing-key-{{ $gen }}{{- end -}}
{{- end -}}

{{- define "inst.authnSigningKeyKid" -}}
{{- $gen := index . 0 | default 1 | int -}}
{{- if le $gen 1 -}}krateo-authn-key-1{{- else -}}krateo-authn-key-{{ $gen }}{{- end -}}
{{- end -}}

{{/* ---------------------------------------------------------------------------------------
     inst.authnPreviousKeys — the OVERLAP list for authn's JWKS, derived from ONE integer
     (authn.jwt.overlapGenerations) on top of the generation counter. Returns a JSON array the
     caller parses with fromJsonArray; a define cannot return a list.

     WHY DERIVED AND NOT SET. keyGeneration is a REVOCATION lever: authn has no per-token
     revocation, so its only purpose is to stop honouring already-issued tokens, and
     compositions.yaml FORCES signKeySecretName and kid for exactly that reason. previousKeys is
     the OPPOSITE lever -- a listed key keeps verifying. Exposed as a plain mirror field the two
     combine into a rotation that invalidates nothing while every signal reports success: new
     Secret created, authn Ready, clean boot. That is the failure check-signing-key.py exists
     for, so the pair must be unexpressible rather than merely refused. An operator writes one
     integer; this derives the list.

     A PREVIOUS KEY NEVER SIGNS. authn's jwks.ParsePreviousKeys reads each file through
     publicKeyFromPEM and keeps ONLY the public half (verified by authn against
     TestParsePreviousKeys, which covers a private PEM and a PKIX PUBLIC KEY). secretKey is
     FORCED to private.pem rather than omitted: authn's chart defaults it to private.pem today,
     but a derived field that silently tracks another chart's default is the coupling the two
     forced fields above already avoid. Retaining the retired PRIVATE key for the overlap is
     therefore a security COST, not a necessity -- a verify-only Secret holding just the public
     half would do. Helm cannot derive a public half from a private PEM (sprig has no such
     function), so that needs a hook Job or the controller and is deliberately NOT in this
     change.

     WHY EXISTENCE IS AN INPUT. authn refuses to START on a previousKeys entry whose Secret or
     key is absent -- the pod hangs mounting the volume, or the parse is a fatal boot error. A
     keyGeneration JUMP (1 -> 3) never creates generation 2's Secret, so a naive
     keyGen-1..keyGen-N range points at a Secret that was never written. Omitting a generation
     that does not exist loses nothing: no token was ever signed with a key that was never
     created. So the caller passes the names it found and this filters to those.

     NEITHER THIS NOR ITS SIBLINGS CALL `lookup`, for the reason spelled out above
     inst.authnSigningKeySecretName: `helm template` disables lookup, so anything downstream of
     it is unreachable in CI. This is a pure function of (generation, overlap, names-that-exist)
     and .github/scripts/check-authn-previous-keys.py renders it directly.
     --------------------------------------------------------------------------------------- */}}
{{- define "inst.authnPreviousKeys" -}}
{{- $gen := index . 0 | default 1 | int -}}
{{- $overlap := index . 1 | default 0 | int -}}
{{- $existing := index . 2 | default (list) -}}
{{- $out := list -}}
{{- $curKid := include "inst.authnSigningKeyKid" (list $gen) -}}
{{- if gt $overlap 0 -}}
{{- range $i := until $overlap -}}
{{- $g := sub $gen (add1 $i) | int -}}
{{- if ge $g 1 -}}
{{- $nm := include "inst.authnSigningKeySecretName" (list $g) -}}
{{- $kid := include "inst.authnSigningKeyKid" (list $g) -}}
{{- /* three refusals authn enforces fatally at startup: a previous kid equal to the current
       one, a duplicate kid, and a Secret that does not exist. */ -}}
{{- if and (ne $kid $curKid) (has $nm $existing) -}}
{{- $dup := "" -}}
{{- range $o := $out -}}{{- if eq (get $o "kid") $kid -}}{{- $dup = "y" -}}{{- end -}}{{- end -}}
{{- if not $dup -}}
{{- $out = append $out (dict "kid" $kid "secretName" $nm "secretKey" "private.pem") -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}

{{/* ---------------------------------------------------------------------------------------
     inst.unmetApiGroups — the API groups a component DECLARES and the cluster does not serve.
     Returns a comma-joined list, or "" when every declared group is present.

     inst.crdExists answers "is this component's own CRD served"; inst.requiresApiGroups answers
     "true"/"" for the gate. Neither can say WHICH group is missing, and the gate's whole failure
     mode is that it emits nothing and explains nothing. This names them.
     --------------------------------------------------------------------------------------- */}}
{{- define "inst.unmetApiGroups" -}}
{{- $want := index . 0 -}}{{- $allCRDs := index . 1 -}}
{{- $missing := list -}}
{{- range $g := ($want | default list) -}}
{{- $found := "" -}}
{{- range $allCRDs -}}{{- if eq .spec.group $g -}}{{- $found = "true" -}}{{- end -}}{{- end -}}
{{- if not $found -}}{{- $missing = append $missing $g -}}{{- end -}}
{{- end -}}
{{- $missing | sortAlpha | join "," -}}
{{- end -}}

{{/* ---------------------------------------------------------------------------------------
     inst.withheldReason — why a DECLARED component is not being emitted, in words, on the
     component the operator actually named.

     THE DEFECT THIS EXISTS FOR (#614). krateo-observability declares no unsatisfied API group of
     its own. It is withheld because clickhouse-operator is, and clickhouse-operator's declaration
     is the only place the real condition is recorded — a component the operator had no reason to
     look at. Every CompositionDefinition in the chain reports True/True, the composition CRs are
     simply never created, and there is no error anywhere. An operator who enables the
     observability tier without features.ingress gets an install that looks entirely healthy and
     emits nothing.

     Measured as a REGRESSION, not a standing gap: installer 0.3.477 has no requiresApiGroups at
     all and installed the whole tier on a fresh cluster with no cert-manager; 0.3.478 introduced
     them (#594) and a fresh install stops at 33 of 40 declared CRs. The snowplow bench bracketed
     it from outside on 0.3.468 (40/40) and 0.3.506 (33/40).

     Reasons are ordered by what the gate checks first, so the reported reason is the one that
     actually blocks. The transitive arm is bounded rather than recursive because helm templates
     cannot recurse; 6 passes covers this chart's deepest chain (operator -> observability ->
     collector-deployment -> collector-daemonset) with room to spare, and a chain deeper than that
     reports the direct cause rather than silently reporting none.
     --------------------------------------------------------------------------------------- */}}
{{- define "inst.withheldReason" -}}
{{- $top := index . 0 -}}{{- $c := index . 1 -}}{{- $components := index . 2 -}}{{- $allCRDs := index . 3 -}}
{{- $own := include "inst.unmetApiGroups" (list $c.requiresApiGroups $allCRDs) -}}
{{- if $own -}}
{{- printf "withheld: this component requires API group(s) %s, which the cluster does not serve" $own -}}
{{- else -}}
{{/* build the set of components whose OWN declared groups are unmet */}}
{{- $unmet := dict -}}
{{- range $x := $components -}}
{{- if $x.requiresApiGroups -}}
{{- $m := include "inst.unmetApiGroups" (list $x.requiresApiGroups $allCRDs) -}}
{{- if $m -}}{{- $_ := set $unmet $x.name $m -}}{{- end -}}
{{- end -}}
{{- end -}}
{{/* bounded transitive walk over deps */}}
{{- $seen := dict -}}
{{- $frontier := ($c.deps | default list) -}}
{{- range $pass := until 6 -}}
{{- $next := list -}}
{{- range $d := $frontier -}}
{{- if not (hasKey $seen $d) -}}
{{- $_ := set $seen $d true -}}
{{- range $x := $components -}}{{- if eq $x.name $d -}}{{- $next = concat $next ($x.deps | default list) -}}{{- end -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- $frontier = $next -}}
{{- end -}}
{{- $blockers := list -}}
{{- range $d, $_v := $seen -}}
{{- if hasKey $unmet $d -}}{{- $blockers = append $blockers (printf "%s needs %s" $d (index $unmet $d)) -}}{{- end -}}
{{- end -}}
{{- if $blockers -}}
{{- printf "withheld: a dependency requires an API group the cluster does not serve -- %s" ($blockers | sortAlpha | join "; ") -}}
{{- else -}}
{{/* Read the SAME resolver inst.emitDecision read, not a separately derived answer to a similar
     question (#477 follow-on). A crdExists-at-the-pin check here names a reason the decision did
     not act on, because the decision now accepts an older served tag. */}}
{{- $etag := include "inst.emitTag" (list $top $c.kind $c.name $c.version $allCRDs) -}}
{{/* Ask existence the way inst.emitDecision asks it -- version-agnostically. A reason derived from
     a different question than the decision acted on is how this reporter came to contradict the
     gate once already. */}}
{{- $any := include "inst.compositionExistsAny" (list $top $c.kind $c.name $allCRDs $c.namespace) -}}
{{- if not $etag -}}
{{- printf "withheld: no CRD serves kind %s at version %s and no live instance exists at any served version to keep alive (normal before first creation; persistent means crdgen rejected the CRD)" $c.kind (toString $c.version) -}}
{{- else if and ($c.deps | default list) (ne $any "true") -}}
{{- printf "withheld: dependencies not Ready yet and no live instance to keep alive -- %s" (($c.deps | default list) | sortAlpha | join ",") -}}
{{- else if ($c.deps | default list) -}}
{{/* A live instance EXISTS and the CRD serves a version, so inst.emitDecision would have emitted
     it on the $exists escape. If this component is nonetheless withheld, the gate and this
     reporter disagree and that must be said, not papered over with the deps message. */}}
{{- printf "withheld: NO REASON FOUND -- a live instance of %s/%s exists at a served version and the $exists escape should have emitted it, so the emission gate and this reporter disagree. That is a bug in one of them; please report it." $c.kind $c.name -}}
{{- else -}}
{{/* No deps, CRD served, no unmet groups -- the gate's own terms are all satisfied, so this
     component should have been emitted. Reaching here means the gate and this reporter disagree,
     which is a defect in one of them and must not print as a reason. An empty dep list rendered
     into "dependencies not Ready yet -- " is the shape that would hide it. */}}
{{- printf "withheld: NO REASON FOUND -- this component has no dependencies, its CRD is served and its declared API groups are present, so the emission gate and this reporter disagree. That is a bug in one of them; please report it." -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/* ---------------------------------------------------------------------------------------
     inst.servedTags — the apiVersion tags a Kind's generated CRD actually SERVES, space-joined.

     inst.crdExists answers "is THIS version served" and cannot say what else is. This can, which
     is what makes it possible to keep a live composition alive at a version the cluster still
     answers on while a bump is in flight.
     --------------------------------------------------------------------------------------- */}}
{{/* --------------------------------------------------------------------------------------
     inst.jsonSchemaConfigmaps — the jsonschema ConfigMap names a blueprint's readers must be able to
     `get`, as a space-separated list. args: (list "Kind" "chartVersion" $allCRDs)

     WHY THE GRANT EXISTS. A tenant's blueprint create form is EMPTY without it. The form's schema
     source is core-provider's `<resource>-<version>-jsonschema-configmap`, and tenants cannot read
     the CRD fallback by design -- so Bob saw "This blueprint is still being registered". Diego chose
     to have core-provider write that ConfigMap next to its CompositionDefinition; this is the read
     grant that lets the group see it once it is there.

     THE NAME FORMAT IS CONFIRMED TWO WAYS by acmp, which is why it is safe to construct:
       code (core-provider 2.13.103): getJsonSchemaConfigmapNN = nn.Name + "-jsonschema-configmap",
         where nn.Name = fmt.Sprintf("%s-%s", gvr.Resource, gvr.Version) -- no truncation, no
         transform, and gvr.Version is the CRD version string (v0-2-61), not the chart's 0.2.61;
       live demo: 55 *-jsonschema-configmap objects, of which 54 of 54 composition ones match
         <plural>-<a SERVED crd version>-jsonschema-configmap exactly. The 55th is
         installer-core-provider-jsonschema-configmap, not a composition CRD, so out of scope.

     THE NAME IS A CONTRACT, AND IT IS NOW TEST-PROTECTED UPSTREAM (asked and answered
     2026-11-24). core-provider#651 makes the ConfigMaps MOUNTED ON THE CORE-PROVIDER POD
     immutable and named by content digest -- `<fullname>-cdc-deployment-<digest>` and so on --
     so an old pod keeps its own templates instead of the kubelet refreshing a new chart's
     templates underneath it (acmp's globex incident rolled 7 broken controllers that way).
     THAT CHANGE DOES NOT TOUCH THESE OBJECTS. The per-composition
     `<plural>-<version>-jsonschema-configmap` names are rendered by core-provider from
     assets/jsonSchemaConfigmap.yaml, whose `name:` is unchanged, and the portal depends on the
     same name (Diego, 2026-11-16). core-provider has asked their build to keep a test on it.
     Four ConfigMaps are mounted on 057, not five: the fifth,
     `<fullname>-service-configmap`, appears only with cdc.metrics.enabled, which 057 does not
     set.
     WHY THIS IS WORTH A PARAGRAPH RATHER THAN A LINE: the derivation below would have broken
     SILENTLY. A name that does not resolve reads as "no such ConfigMap", not as an error, so a
     digest-renaming of these objects would have produced an absence rather than a failure. The
     answer is recorded here because the next person to read this lookup will ask the same
     question, and the announcement that prompted it did not distinguish the 4 mounted objects
     from the 55 per-composition ones.

     THE PLURAL COMES FROM THE CRD, NOT FROM A RULE. `SelfserviceKrateo` pluralises to
     `selfservicekrateoes`, which crdgen decides and no pluralisation rule I could write would
     reproduce. So it is read from the CRD whose group is composition.krateo.io and whose names.kind
     matches -- the same match inst.servedTags makes.

     EVERY SERVED VERSION *PLUS* THE PINNED ONE, deduped, and that removes a window acmp had already
     accepted. During a version bump the portal reads .compdef.status.apiVersion, so a grant naming
     only the pinned version leaves the form empty until the CD migrates; one naming only the served
     version goes stale forever. Naming both means the OUTGOING ConfigMap stays readable until its CRD
     version stops being served, and the INCOMING one is readable the moment it exists. The list is
     rebuilt every render, so a version that stops being served drops out by itself.

     EMPTY WHEN LOOKUP IS EMPTY, deliberately. Under `helm template` lookup is disabled, $allCRDs is
     empty, and the plural is unknowable -- so this returns nothing and the caller omits the rule.
     An absent rule is a visible empty form; a GUESSED resourceNames entry is a grant that silently
     matches nothing, which looks configured and is not.
     -------------------------------------------------------------------------------------- */}}
{{- define "inst.jsonSchemaConfigmaps" -}}
{{- $kind := index . 0 -}}{{- $ver := index . 1 -}}{{- $allCRDs := index . 2 -}}
{{- $plural := "" -}}
{{- $served := list -}}
{{- range $allCRDs -}}
{{- if and (eq .spec.group "composition.krateo.io") (eq .spec.names.kind $kind) -}}
{{- $plural = .spec.names.plural -}}
{{- range .spec.versions -}}{{- if .served -}}{{- $served = append $served .name -}}{{- end -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- $out := list -}}
{{- if $plural -}}
{{- $want := printf "v%s" ($ver | toString | replace "." "-") -}}
{{- range $t := (append $served $want | uniq) -}}
{{- if $t -}}{{- $out = append $out (printf "%s-%s-jsonschema-configmap" $plural $t) -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- $out | uniq | sortAlpha | join " " -}}
{{- end -}}


{{- define "inst.servedTags" -}}
{{- $kind := index . 0 -}}{{- $allCRDs := index . 1 -}}
{{- $tags := list -}}
{{- range $allCRDs -}}
{{- if and (eq .spec.group "composition.krateo.io") (eq .spec.names.kind $kind) -}}
{{- range .spec.versions -}}{{- if .served -}}{{- $tags = append $tags .name -}}{{- end -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- $tags | join " " -}}
{{- end -}}

{{/* ---------------------------------------------------------------------------------------
     inst.emitTag — THE single resolution of "which apiVersion is this component emitted at".

     Returns an apiVersion tag (e.g. `v1-8-90`), or "" when nothing should be emitted. The gate,
     the existence check and the emitted `apiVersion:` all call this, because deriving that fact at
     more than one call site is exactly how they come to disagree -- the defect this fixes.

     THE DEFECT (installer#477). The gate used to AND `inst.crdExists $c.version` OUTSIDE the
     `$exists` escape. At the instant a component's pin bumps, the generated CRD does not yet serve
     the new version -- the bumped CompositionDefinition is what causes crdgen to create it -- so
     the conjunct failed, `$exists` was never consulted, the composition vanished from the manifest
     and helm PRUNED the live CR. The escape added on 2026-07-08 to stop exactly that could not
     help, because it sat inside the conjunct that failed.

     Measured, not theorised: the identical construction in krateo-blueprints' openstack umbrella
     pruned 34 live composition CRs on 2026-11-04, leaving 27 helm releases with nothing driving
     them. Their escape was MORE permissive than ours -- version-agnostic -- and it made no
     difference, because the outer conjunct fails first. And core-provider measured their half:
     ApplyOrUpdateCRD waited on `crd.IsReady`, which checks only `Established` -- already true from
     the PREVIOUS version and never false across an update -- so nothing had ever established that
     the new version was servable. Their #343 bounds that window; it cannot order their return
     against this template's next render.

     THE RESOLUTION, in order:
       1. the target version is served            -> the target. Steady state, and the normal case
                                                     once crdgen has caught up.
       2. the target is NOT served, but the live instance exists at a version that IS
                                                  -> THAT version. The bump instant: keep rendering
                                                     the object that already exists, at a version the
                                                     cluster still serves. Two separate reasons, and
                                                     they are worth keeping apart because they fail
                                                     differently:
                                                       PRESENT rather than absent -- this is what
                                                         stops the prune. Helm prunes what leaves the
                                                         manifest; the defect above is an ABSENCE,
                                                         not a version mismatch.
                                                       at a SERVED version -- this is what stops the
                                                         apply being REJECTED. Emitting an unserved
                                                         apiVersion is a different failure from being
                                                         pruned, and reads nothing like it.
                                                     Deliberately NOT claimed here: that helm would
                                                     treat the same object at a new apiVersion as a
                                                     delete-and-create. openstack-as-a-service
                                                     measured the opposite on k3s (helm does not match
                                                     on version) and core-provider confirmed it in
                                                     plumbing's Reconcile; this session has not
                                                     reproduced either, so the reasoning above is
                                                     written to hold whichever way that falls.
                                                     It migrates on a later pass, once (1) becomes
                                                     true.
       3. neither                                 -> "". First creation before the CRD is servable,
                                                     or a CRD crdgen rejected. Withholding is
                                                     correct: there is nothing to preserve and no
                                                     version to emit at.

     Case 2 is the whole fix. It is deliberately conditioned on the instance EXISTING: without that
     it would emit a brand-new object at a stale version, which is a different defect.
     --------------------------------------------------------------------------------------- */}}
{{/* inst.emitTagFrom — the DECISION, as a pure function of facts already gathered.

     Split out from inst.emitTag for the same reason inst.jwtSigningKeyPEM was split from
     secret.yaml: the resolution's interesting arm depends on a `lookup`, and `helm template`
     DISABLES lookup -- so while the decision lived beside its own lookup, the only arm a test
     could reach was the one that does not matter. Taking the lookup's RESULT as an argument makes
     every arm reachable with no cluster and no fake-cluster plugin.

     Arguments: the wanted tag, the space-joined served tags, and the tag at which the live
     instance was found ("" if it was not found, or if lookup was unavailable). */}}
{{- define "inst.emitTagFrom" -}}
{{- $want := index . 0 -}}{{- $servedStr := index . 1 -}}{{- $existingTag := index . 2 -}}
{{- $served := splitList " " ($servedStr | toString) -}}
{{- if has $want $served -}}{{- $want -}}
{{- else if and $existingTag (has $existingTag $served) -}}{{- $existingTag -}}
{{- end -}}
{{- end -}}

{{- define "inst.emitTag" -}}
{{- $top := index . 0 -}}{{- $kind := index . 1 -}}{{- $name := index . 2 -}}{{- $ver := index . 3 -}}{{- $allCRDs := index . 4 -}}
{{- $want := printf "v%s" ($ver | toString | replace "." "-") -}}
{{- $servedStr := include "inst.servedTags" (list $kind $allCRDs) -}}
{{/* Find the tag the live instance is actually served at, if any. Only consulted when the wanted
     tag is not served -- that is the bump instant -- so the common path costs no extra lookup. */}}
{{- $existing := "" -}}
{{- if not (has $want (splitList " " $servedStr)) -}}
{{- range $t := splitList " " $servedStr -}}
{{- if and (not $existing) $t -}}
{{- if lookup (printf "composition.krateo.io/%s" $t) $kind $top.Values.namespaces.krateo $name -}}
{{- $existing = $t -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- include "inst.emitTagFrom" (list $want $servedStr $existing) -}}
{{- end -}}

{{/* inst.compositionExistsAny — does the live instance exist at ANY SERVED tag?
     args: (list $ "Kind" "name" $allCRDs)

     This is the right shape for every EXISTENCE question, and the wrong one for the emitted
     apiVersion. The two must not share a helper, which is the mistake this replaces.

     inst.emitTag PREFERS THE TARGET, correctly: once crdgen serves the new version that is what a
     composition should be emitted at, so the cdc performs the origin-version migration. But asking
     "does this still exist?" at the tag we would EMIT it at is a DIFFERENT question, and it is
     wrong in a cell the first #477 fix did not cover: when the CRD serves the old AND the new
     version and the instance has not migrated yet, inst.emitTag returns the new tag, a lookup
     there MISSES the instance living at the old one, and the caller concludes it is gone. For
     inst.dependentsGone that deletes a draining component WITH A DEPENDENT STILL PRESENT; for
     inst.compositionExists it deregisters a CompositionDefinition under a live CR; for the gate's
     own escape it prunes the instance it exists to protect.

     krateo-blueprints' openstack umbrella uses a version-agnostic escape and said so; this is why.
     An existence check must be permissive, because its job is to STOP a deletion. */}}
{{/* inst.declaredSpecKeys — the top-level `spec` property names a (Kind, served tag) can HOLD.
     args: (list "Kind" "v0-2-6" $allCRDs)
     returns: "*" when it cannot be determined or the schema is OPEN, else the space-joined key names.

     WHY A SENTINEL RATHER THAN AN EMPTY STRING. "" is ambiguous: it is also what a CRD declaring zero
     spec properties would yield, and a caller reading "" as "allow everything" would then write into
     a schema that holds nothing. "*" says "no opinion" and nothing else can produce it.

     WHY THIS EXISTS. The chart writes installer-computed wiring onto component CRs. Where the CRD
     version it is written AT does not declare the key, the apiserver PRUNES it and the write reports
     success. Measured on 057 against the umbrella's own helm manifest (installer#936):

         key              written  declared  PRUNED
         hitlApproval          8         5       3   ClickstackAgent, IncidentAgent, NightlyReview
         rollGuard             9         8       1   NightlyReview
         vertexAI             10         9       1   NightlyReview
         agentgateway         11        10       1   NightlyReview

     All three owners confirmed the keys are genuinely INERT for their agents and declined to declare
     them just to turn a gate green -- which was the right instinct, and is why the fix belongs here.

     FAIL-SAFE DIRECTION IS DELIBERATE. When the CRD or the version is absent, or the schema is open,
     this returns "*" and callers write the key as they do today. The current behaviour is "write and
     let the apiserver prune", so falling back to it is never worse than today -- whereas failing
     closed would silently stop writing values that DO land, which is a regression nobody would see.
     A lookup returning nothing is the normal state under `helm template`, so this matters. */}}
{{- define "inst.declaredSpecKeys" -}}
{{- $kind := index . 0 -}}{{- $tag := index . 1 -}}{{- $allCRDs := index . 2 -}}
{{- $out := "*" -}}
{{- range $crd := (default list $allCRDs) -}}
{{- if and (eq (dig "spec" "group" "" $crd) "composition.krateo.io") (eq (dig "spec" "names" "kind" "" $crd) $kind) -}}
{{- range $v := (default list (dig "spec" "versions" list $crd)) -}}
{{- if and $v.served (eq ($v.name | toString) ($tag | toString)) -}}
{{- $sp := dig "schema" "openAPIV3Schema" "properties" "spec" dict $v -}}
{{- $props := dig "properties" dict $sp -}}
{{- $preserve := dig "x-kubernetes-preserve-unknown-fields" false $sp -}}
{{- $addl := dig "additionalProperties" false $sp -}}
{{/* additionalProperties: false is CLOSED. additionalProperties: {a schema} is open. */}}
{{- $openAddl := kindIs "map" $addl -}}
{{- if or $preserve $openAddl -}}
{{- $out = "*" -}}
{{- else if $props -}}
{{- $out = (keys $props | sortAlpha | join " ") -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $out -}}
{{- end -}}


{{/* inst.canHold — may this (Kind, tag) hold `spec.<key>`?  "true" or "".
     args: (list "Kind" "v0-2-6" $allCRDs "hitlApproval")

     "*" from inst.declaredSpecKeys means no opinion, so this returns "true" -- see the fail-safe
     note there. The point of routing every write site through ONE predicate is that the steady-state
     prune (#936) and the BUMP-INSTANT prune are the same question asked at different moments: acmp
     pinned keycloak 0.4.1 and set a new node's value in the same roll, inst.emitTagFrom emitted the
     CR at the OLD served version whose schema lacked the node, and the value was pruned while the
     write reported success. One predicate, both moments. */}}
{{- define "inst.canHold" -}}
{{- $kind := index . 0 -}}{{- $tag := index . 1 -}}{{- $allCRDs := index . 2 -}}{{- $key := index . 3 -}}
{{- $declared := include "inst.declaredSpecKeys" (list $kind $tag $allCRDs) -}}
{{- if eq $declared "*" -}}true
{{- else if has $key (splitList " " $declared) -}}true
{{- end -}}
{{- end -}}


{{- define "inst.compositionExistsAny" -}}
{{- $top := index . 0 -}}{{- $kind := index . 1 -}}{{- $name := index . 2 -}}{{- $allCRDs := index . 3 -}}
{{/* THE NAMESPACE IS A PARAMETER, and before 2026-11-18 it was hardcoded to namespaces.krateo.
     That was correct while every composition instance lived there. It stopped being correct in the
     change that let a pinned component target its own namespace (installer#1029):
     compositions.yaml now emits `namespace: {{ $c.namespace | default ... }}`, so a
     namespace-targeted component's instance is NOT in namespaces.krateo and a lookup there finds
     nothing.

     WHICH CONSUMER THIS ACTUALLY BREAKS. I first wrote that the hazard was inst.emitDecision's
     `or $deps $exists` escape hatch never opening, so a deps flap would prune a live workload. THAT
     IS WRONG for the component this matters for: inst.depsReady starts at "true" and ranges over
     the dep list, so a component with NO deps -- which kyverno is -- always has $deps="true" and
     never consults $exists at all. I measured that after writing the claim, not before.

     The reachable consumer is definitions.yaml's third arm:

         {{- if or $c.registerOnly (compEnabled ...) (compositionExists ...) }}

     which keeps a DEFINITION registered while its composition is still live. Read with the wrong
     namespace it is permanently false, so with the FEATURE OFF and a composition still present the
     CompositionDefinition is deregistered and its generated CRDs garbage-collected out from under
     that live composition. The helper's own comment two definitions below calls this "the
     orphaned-CR outcome this helper was added to prevent".

     WHY IT IS REACHABLE AND NOT THEORETICAL. kyverno is gated on features.identityLifecycle, TRUE
     on demo and FALSE on 057, and demo's Kyverno release already exists in namespace `kyverno` --
     adopting it is what tag K does. So turning identityLifecycle off on demo, for any reason, would
     GC the Kyverno CRDs from under a running install, and ClusterPolicy tenant-namespace-on-login
     depends on that install. The keycloak-provider-kog session is holding off exactly that step in
     its Arm A rehearsal until this is fixed.

     inst.dependentsGone and the withheld reporter take the same parameter for the same reason: a
     reason derived from a different question than the decision acted on is how that reporter came
     to contradict the gate once already.

     THIS CHANGE HAS NO UNIT TEST, AND THAT IS A HARNESS LIMIT RATHER THAN A CHOICE. I tried to
     build one and measured why it cannot exist here: helm-unittest's `lookup` fake does not serve
     this composition lookup at all. definitions.yaml renders 41 documents with the feature off and
     41 with the feature off PLUS a Kyverno composition fixture -- the third arm never fires. I then
     forced the lookup back to namespaces.krateo with the fixture ALSO in namespaces.krateo, so both
     sides agreed on the release namespace, and it was still 41. So the failure is the fake, not the
     namespace, and no arrangement of fixtures can exercise this path. (The same harness DOES serve
     other namespaced custom resources -- httproutes_test.yaml documents kind-specific quirks in it,
     including a kind named `Gateway` resolving to an empty dict whatever group it is under.)

     THE CONTROL THAT PROVES THE PATH IS REACHABLE AT ALL: with features.identityLifecycle TRUE the
     kyverno CompositionDefinition renders and `spec.chart.version: 3.9.4` is selectable, and the
     document count goes 41 -> 45. So the template and the selector are right; only the lookup is
     unserved.

     SO THE VERIFICATION IS AN INTEGRATION STEP, named rather than skipped: on a cluster where a
     Kyverno composition is LIVE in namespace `kyverno`, turn features.identityLifecycle OFF and
     assert the CompositionDefinition is still registered and its CRDs still present. That is
     precisely the step keycloak-provider-kog is holding in its Arm A rehearsal, and it is the only
     place this can be measured. Do not record this as verified until that step reports. */}}
{{- $ns := index . 4 -}}
{{- if not $ns -}}{{- $ns = $top.Values.namespaces.krateo -}}{{- end -}}
{{- $found := "" -}}
{{- range $t := splitList " " (include "inst.servedTags" (list $kind $allCRDs)) -}}
{{- if and (not $found) $t -}}
{{- if lookup (printf "composition.krateo.io/%s" $t) $kind $ns $name -}}{{- $found = "true" -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- $found -}}
{{- end -}}


{{/* ---------------------------------------------------------------------------------------
     inst.componentValuesPatch — componentValues for the CR merge patch, with explicit nulls
     for every path named in .Values.componentValuesUnset.

     WHY THIS EXISTS. components-patch.json is applied as an RFC-7386 merge patch, where an
     OMITTED key is PRESERVED and only an explicit null deletes. That is deliberate — it is what
     stops a chart upgrade clobbering operator-set values (see self-bootstrap.yaml) — but it also
     means a componentValues key could be SET and CHANGED and never REMOVED. Deleting it from the
     values file was silently inert: helm reported the new values while the CR kept the old ones.

     Measured on krateo-057, 2026-11-07: after removing componentValues.authn.env entirely and
     rolling 0.3.519, the live CR still held {"env":{"AUTHN_DEBUG":"false","AUTHN_DUMP_ENV":"false"}}
     and the rendered ConfigMap still carried AUTHN_DUMP_ENV. A sweep then found NINE components
     whose live componentValues were explained by neither the values file nor a schema default —
     so the CR was no longer reconstructible from the repo.

     An explicit null in the VALUES cannot express this: the schema types these fields (string,
     object), so helm refuses a null before the patch is ever built. Hence a separate, additive
     key whose only job is removal — it loosens no existing type, and it makes a removal a
     DECLARED act that a gate can check rather than an impossible one.

     Paths are dotted and relative to componentValues:
         componentValuesUnset:
           - authn.env.AUTHN_DUMP_ENV      removes that one key
           - authn.env                     removes the whole object
     A path whose parent is absent is a no-op, not an error: re-running an unset after it has
     taken effect must stay safe, or the values file becomes un-rerunnable.
*/}}
{{/*
inst.componentValuesResolved — .Values.componentValues plus DERIVED defaults that cannot live in
values.yaml because they depend on other values.

WHY THIS EXISTS. A blueprint chart whose values.schema.json marks a key `required` makes that key
MANDATORY on the generated Composition CR, and the umbrella emits that CR carrying only what
componentValues supplies — the component chart's own values.yaml defaults do NOT populate it. So a
missing required key makes the CR uncreatable, and because the rejection happens inside the
Installer composition's own helm reconcile it freezes EVERY component. Measured twice on
krateo-demo 2026-11-11: keycloak 0.2.3 (`spec.db`/`spec.keycloak`) froze all 108 managed children.

A plain default in values.yaml covers the keys that are constant. This helper covers the ones that
are NOT: keycloak-config-kog's `keycloak.baseUrl` is an in-cluster Service URL whose NAMESPACE is
whatever `namespaces.krateo` is set to. Hardcoding the upstream chart's own default would be wrong
for us twice over — it names `keycloak-system`, while Krateo installs every composition into
`namespaces.krateo` (krateo-system on both 057 and demo), and it would silently stop being true the
moment someone changed that value.

An explicitly set componentValues value always wins; this only fills an ABSENT key.

Returns the resolved map. Used by the fresh-install CR AND, through inst.componentValuesPatch, by
the surgical upgrade patch — so the two paths cannot drift.
*/}}
{{/* --------------------------------------------------------------------------------------
     inst.kogUrls — keycloak-config-kog's three DERIVED values, as a map.
     args: (list $top)   ->  JSON {baseUrl, tokenEndpoint, bootstrapNamespace}

     EXTRACTED SO IT CAN BE TESTED, exactly as inst.platformRoutes was. The derivation lived inline
     in compositions.yaml, and that file emits a component only when all its `deps` are Ready
     (Pass B, inst.depsReady) -- keycloak-config-kog has SIX. So asserting it through a render needs a
     fixture carrying six Ready dep compositions, which is a lot of scaffolding to get at three
     printf calls. A helper can be probed directly with synthetic values.

     WHY THESE ARE DERIVED AND NOT FILLED. They used to be filled into the CR by
     inst.componentValuesResolved "only if absent". That helper feeds BOTH the fresh-install CR and
     inst.componentValuesPatch -- the merge patch applied on EVERY upgrade -- so the value was written
     into the CR, became explicit, and the guard never fired again. keycloak-provider-kog measured the
     consequence on krateo-057: both URLs frozen WITHOUT /keycloak since first install, so #968's
     relativePath derivation was correct and unreachable.

     relativePath is trimSuffix'd. values.schema.json's pattern already refuses `/keycloak/` and `/`
     at chart load, so this is unreachable from a NEW value -- it exists for a value that was written
     before the pattern did, which is the case a schema cannot repair. Keeping it is cheap; relying on
     the pattern alone would not cover the clusters that already carry one.
     -------------------------------------------------------------------------------------- */}}
{{- define "inst.kogUrls" -}}
{{- $top := index . 0 -}}
{{- $ns := $top.Values.namespaces.krateo -}}
{{- $rel := trimSuffix "/" (dig "keycloak" "keycloak" "http" "relativePath" "" (default dict $top.Values.componentValues)) -}}
{{- dict
     "baseUrl" (printf "http://keycloak-service.%s.svc.cluster.local:8080%s" $ns $rel)
     "tokenEndpoint" (printf "http://keycloak-service.%s.svc.cluster.local:8080%s/realms/master/protocol/openid-connect/token" $ns $rel)
     "bootstrapNamespace" $ns
   | toJson -}}
{{- end -}}


{{- define "inst.componentValuesResolved" -}}
{{- $top := . -}}
{{- $cv := deepCopy (default dict $top.Values.componentValues) -}}
{{- $ns := $top.Values.namespaces.krateo -}}
{{- $known := dict -}}
{{- range $c := (include "inst.componentsYaml" $top | fromYaml).components -}}
{{- $_ := set $known (toString $c.name) true -}}
{{- end -}}
{{/* keycloak-config-kog's derived baseUrl, tokenEndpoint and auth.bootstrap.namespace USED TO BE
     FILLED HERE, "only if absent". They are now derived in compositions.yaml with inst.forcePath, and
     the move is a BUG FIX rather than a tidy-up.

     THIS HELPER IS CALLED FROM TWO PLACES: the fresh-install CR (self-bootstrap.yaml) and
     inst.componentValuesPatch below, which is the merge patch applied on EVERY upgrade. So anything
     filled here is WRITTEN INTO THE INSTALLER CR, becomes an explicit operator value, and the "only
     if absent" guard never fires again for that cluster. A derivation placed here is frozen at first
     install.

     keycloak-provider-kog measured it on krateo-057: the CR carries both URLs WITHOUT /keycloak, and
     a render with 057's values reproduced it while the control -- the same render with those two keys
     deleted -- produced the correct /keycloak form. So #968's relativePath derivation was right and
     unreachable on every existing cluster.

     forcePath in compositions.yaml runs BEFORE the componentValues merge, and that merge uses `merge`
     rather than `mergeOverwrite`, so the destination wins: the stale persisted keys are overridden at
     render and no componentValuesUnset is needed anywhere.

     DO NOT ADD A FILL-IF-ABSENT DERIVATION HERE. If a value must be computed, compute it at render in
     compositions.yaml. This helper is for resolving what the OPERATOR set, plus the explicit nulls
     componentValuesUnset needs -- not for installer-computed wiring. */}}
{{- $cv | toJson -}}
{{- end -}}

{{/* ---------------------------------------------------------------------------------------
     inst.componentsPatchList — the effective components list with PIN-OWNED KEYS REMOVED from
     pinned entries, for writing back to the Installer CR.

     WHY THIS EXISTS. The self-bootstrap merge-patches the effective `components` list onto the live
     CR so chart-side pins reach the cluster. Writing pin-owned keys into that list is what froze
     krateo-057 on 2026-11-18: the CR's spec.components arrives as .Values.components on the next
     render, so a `namespace` that the PINS FILE decided came back through the OVERRIDE path and hit
     a guard meant for per-cluster overrides. The guard is no longer fatal, but the cause is here:
     the CR should hold what a CLUSTER overrides, never a copy of what the pin already decides.

     This was the acmp session's diagnosis, and their argument for fixing the writer rather than
     only relaxing the reader is the reason this helper exists: with a stale copy in the CR, ANY
     later change to a pin-owned field collides with it. Remove the copy and the collision cannot
     occur, whatever the reader does.

     PINNED ENTRIES ONLY. An appended registerOnly catalog blueprint keeps its namespace and
     readerGroups, because for those the CR is the ONLY source -- stripping them would delete a
     cluster's own configuration. The discriminator is presence in files/component-pins.min.yaml. */}}
{{/* ---------------------------------------------------------------------------------------
     inst.ignoredPinOwnedOverrides — the pin-owned keys that .Values.components tried to set on a
     PINNED component, and which the merge therefore ignored. Returned as a JSON map of
     "<component>.<key>" -> the ignored value.

     WHY THIS EXISTS. As of 2026-11-18 a pin-owned key on a pinned component is IGNORED rather than
     refused, because refusing froze krateo-057 (chart-inspector HTTP 500, unclearable by rollback).
     Ignoring is right for the render -- but an ignored override with no trace is the same failure
     class as the Installer CRD silently PRUNING an undeclared key: someone sets a namespace, every
     tool reports success, and the value never takes effect. That class has cost this repo four
     separate releases.

     This was the acmp session's point, made immediately after they had talked me out of the
     refuse-on-mismatch design. Inert for the render, visible in the report.

     THE EXPECTED CASE IS NOT REPORTED, and that distinction is the whole design. The self-bootstrap
     writes pin-owned keys into the CR on any chart that predates inst.componentsPatchList, and the
     CR comes back as .Values.components -- so an ECHO of the pin's own value is the machine talking
     to itself and says nothing to an operator. Only a value that DISAGREES with the pin represents
     an intent that did not take effect, and only that is worth a line. Otherwise this report would
     be full on every cluster for one pass after an upgrade and read as noise. */}}
{{- define "inst.ignoredPinOwnedOverrides" -}}
{{- $top := . -}}
{{- $pins := dict -}}
{{- range $c := (($top.Files.Get "files/component-pins.min.yaml" | fromYaml).components | default list) -}}
{{- $_ := set $pins (toString $c.name) $c -}}
{{- end -}}
{{- $ignored := dict -}}
{{- range $o := ($top.Values.components | default list) -}}
{{- if and (kindIs "map" $o) (hasKey $o "name") -}}
{{- $pin := index $pins (toString $o.name) -}}
{{- if $pin -}}
{{- range $k := (list "namespace" "readerGroups") -}}
{{- if hasKey $o $k -}}
{{- $want := index $o $k -}}
{{- $have := (get $pin $k) -}}
{{- if ne (toString $want) (toString ($have | default "")) -}}
{{- $_ := set $ignored (printf "%s.%s" (toString $o.name) $k) (toString $want) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $ignored | toJson -}}
{{- end -}}


{{- define "inst.componentsPatchList" -}}
{{- $top := . -}}
{{- $pinned := dict -}}
{{- range $c := (($top.Files.Get "files/component-pins.min.yaml" | fromYaml).components | default list) -}}
{{- $_ := set $pinned (toString $c.name) true -}}
{{- end -}}
{{- $out := list -}}
{{- range $c := (include "inst.componentsYaml" $top | fromYaml).components -}}
{{- if hasKey $pinned (toString $c.name) -}}
{{- $clean := dict -}}
{{- range $k, $v := $c -}}
{{- if not (or (eq $k "namespace") (eq $k "readerGroups")) -}}{{- $_ := set $clean $k $v -}}{{- end -}}
{{- end -}}
{{- $out = append $out $clean -}}
{{- else -}}
{{- $out = append $out $c -}}
{{- end -}}
{{- end -}}
{{- $out | toJson -}}
{{- end -}}


{{- define "inst.componentValuesPatch" -}}
{{- /* Builds components-patch.json's componentValues, turning every componentValuesUnset path into
       an EXPLICIT NULL so the RFC-7386 merge patch DELETES it. An omitted key is PRESERVED by that
       patch, and the schema types these fields so a literal null cannot be written in values — so
       without this, a componentValues key can be set and changed and never removed.

       IT CREATES THE INTERMEDIATE MAPS RATHER THAN REQUIRING THEM. The first version walked the
       path and emitted a null only if every parent was ALREADY PRESENT in .Values.componentValues.
       That made the feature useless in the ONLY sequence that occurs: an operator removes the key
       from the values file, discovers on the next roll that the live CR still carries it (because
       omission preserves), and THEN adds the unset — by which point the parent is gone from values,
       the walk fails, and no null is emitted. MEASURED on krateo-057 at 0.3.524:
       componentValuesUnset: [authn.env] with componentValues.authn absent from the values produced
       NO null, and the CR kept {"env":{"AUTHN_DEBUG":"false","AUTHN_DUMP_ENV":"false"}}.

       Deleting an already-absent key is a no-op under RFC-7386, so emitting the null
       unconditionally stays idempotent — re-running a values file after the unset has taken effect
       remains safe, which was the property the existence guard was protecting.

       THE FIRST SEGMENT IS TYPO-GUARDED, and it has to be. Creating intermediates means a typo
       would mint a componentValues entry for a component that does not exist — and
       componentValues is `additionalProperties: false` and typed per component in the Installer
       CRD, so the API server would REJECT THE WHOLE PATCH. One mistyped unset would therefore
       break every componentValues update rather than just its own. So an unknown component name
       fails the render loudly, exactly as an unknown name does in inst.componentsYaml. */}}
{{- $top := . -}}
{{- $cv := (include "inst.componentValuesResolved" $top) | fromJson -}}
{{- $known := dict -}}
{{- range $c := (include "inst.componentsYaml" $top | fromYaml).components -}}
{{- $_ := set $known (toString $c.name) true -}}
{{- end -}}
{{- range $path := (default list $top.Values.componentValuesUnset) -}}
{{- $segs := splitList "." $path -}}
{{- if lt (len $segs) 2 -}}
{{- fail (printf "componentValuesUnset[%s]: a path needs at least <component>.<key>; unsetting a whole component is not supported, because componentValues is required per component" $path) -}}
{{- end -}}
{{- $comp := first $segs -}}
{{- if not (hasKey $known $comp) -}}
{{- fail (printf "componentValuesUnset[%s]: '%s' is not a known component. Creating its entry would mint a componentValues key the Installer CRD rejects (additionalProperties: false), breaking EVERY componentValues update, not just this one. Check the spelling against files/component-pins.yaml." $path $comp) -}}
{{- end -}}
{{- $leaf := last $segs -}}
{{- $cur := $cv -}}
{{- range $seg := (initial $segs) -}}
{{- if not (and (kindIs "map" $cur) (hasKey $cur $seg) (kindIs "map" (index $cur $seg))) -}}
{{- $_ := set $cur $seg dict -}}
{{- end -}}
{{- $cur = index $cur $seg -}}
{{- end -}}
{{- $_ := set $cur $leaf nil -}}
{{- end -}}
{{- $cv | toJson -}}
{{- end -}}

{{/*
inst.subAgents — DERIVE the agentgateway's A2A delegation-target list from the pinned components.

Args: (list $top $components)
Returns: a YAML list of {name, port, subjects}, or "" when nothing qualifies.

EXTRACTED FROM compositions.yaml SO IT CAN BE TESTED AT ALL. The derivation needs no `lookup` —
only $components, $top.Values.componentValues and inst.featureEnabled — but it used to sit inline in
compositions.yaml, and THAT FILE IS lookup-GATED (line 37 reads the live CRD list). `helm template`
disables lookup, so the file renders ZERO composition objects and the derivation could not be
exercised locally in any way. As a named helper it is reachable from a probe chart by plain render.

The orchestrator's own route name comes from the pin's `agentName`, defaulting to "autopilot" so
every pin that does not set it renders byte-identically. With TWO orchestrators pinned side by side
(krateo-autopilot frozen at 0.7.3 and agentiko 0.8.0 during the rename) a literal emitted the SAME
name twice: one duplicate entry and NO route for the second agent.

A non-orchestrator agent is routed by its `agentName` when set, else its chart name, else
the component name. agentName was previously read for ORCHESTRATORS ONLY, so a non-orchestrator
that sets it was silently routed under the wrong name -- nightly-review's Agent object is
`nightly-review-agent` while its component and chart are both `nightly-review`, so its route
would have pointed at a Service that does not exist.
*/}}
{{/*
inst.agentObjectName — the ONE derivation of the kagent Agent OBJECT name a component produces.
Args: (list $comp). Returns the bare name.

WHY THIS IS A HELPER AND NOT AN EXPRESSION. It was an expression, written out twice: once in
inst.subAgents (the agentgateway route) and once inline in compositions.yaml (the orchestrator's
auto-derived A2A fleet). #893 fixed ONE of them to read `agentName` and left the other, and the
divergence took 057's whole umbrella to Ready=False for over three hours: the route pointed at
`nightly-review-agent` while the fleet entry said `nightly-review`, so kagent refused to compile
the orchestrator with `Agent.kagent.dev "nightly-review" not found`. Every other fleet member
carries the `-agent` suffix; nightly-review is the only component whose Agent object name differs
from both its component name and its chart name, so it is the only one that could expose this.

The precedence is agentName, then chart, then component name. `default` is
`default <fallback> <value>`, so the nesting reads inside-out.
*/}}
{{- define "inst.agentObjectName" -}}
{{- $comp := index . 0 -}}
{{- default (default $comp.name $comp.chart) $comp.agentName -}}
{{- end -}}

{{/*
inst.fleetAgents — an orchestrator's AUTO-DERIVED A2A sub-agent fleet: every feature-enabled
non-orchestrator `agent` component, under the name its Agent object actually has.
Args: (list $top $components). Returns `agents: <yaml list of {name}>`, so the caller does
(include "inst.fleetAgents" (list $top $components) | fromYaml).agents.

EXTRACTED FROM compositions.yaml 2026-11-14, for the same reason inst.subAgents and
inst.platformRoutes were: that file LISTs every CRD with `lookup` at its head, `helm template`
DISABLES lookup, so it renders ZERO composition objects and nothing in it can be exercised by a
plain render. The derivation was therefore untestable where it lived.

AND IT WAS WORSE THAN UNTESTABLE. check-subagents could not reach it, so the gate carried its own
INLINE COPY of the derivation to test instead. That copy drifted in two ways at once: it kept the
old name expression, and it gated on inst.featureEnabled where the chart gates on
inst.compEnabled, which also honours alsoFeatures. So the gate was green on a component the chart
would have included and a name the chart would not have produced. A test that restates the rule
agrees with itself and proves nothing about the shipped code.
*/}}
{{- define "inst.fleetAgents" -}}
{{- $top := index . 0 -}}
{{- $components := index . 1 -}}
agents:
{{- range $comp := $components }}
{{- if and $comp.agent (not $comp.orchestrator) (eq (include "inst.compEnabled" (list $top $comp)) "true") }}
  - name: {{ include "inst.agentObjectName" (list $comp) }}
{{- end }}
{{- end }}
{{- end -}}

{{- define "inst.subAgents" -}}
{{- $top := index . 0 -}}
{{- $components := index . 1 -}}
{{- $subAgents := list -}}
{{- range $comp := $components }}
{{- if and $comp.agent (eq (include "inst.compEnabled" (list $top $comp)) "true") }}
{{- if $comp.orchestrator }}
{{- $ap := dig $comp.name dict (default dict $top.Values.componentValues) }}
{{- $subAgents = append $subAgents (dict "name" (default "autopilot" $comp.agentName) "port" 8080 "subjects" (dict "anyAuthenticated" true)) }}
{{- /* A sub-agent's route is contributed ONLY by the orchestrator that OWNS its Agent object.
       `owned: false` means another release owns it, so contributing the route here would emit the
       SAME name twice while two orchestrators are pinned side by side — k8s-agent and helm-agent
       each appearing once per orchestrator. `owned` is absent on every pin today and the charts
       default it to true, so `(ne ... false)` keeps the single-orchestrator render identical. */ -}}
{{- if and (dig "agents" "k8s" "enabled" false $ap) (ne (dig "agents" "k8s" "owned" true $ap) false) }}{{- $subAgents = append $subAgents (dict "name" "k8s-agent" "port" 8080 "subjects" (dict "anyAuthenticated" true)) }}{{- end }}
{{- if and (dig "agents" "helm" "enabled" false $ap) (ne (dig "agents" "helm" "owned" true $ap) false) }}{{- $subAgents = append $subAgents (dict "name" "helm-agent" "port" 8080 "subjects" (dict "anyAuthenticated" true)) }}{{- end }}
{{- else }}
{{- $subAgents = append $subAgents (dict "name" (include "inst.agentObjectName" (list $comp)) "port" 8080 "subjects" (dict "anyAuthenticated" true)) }}
{{- end }}
{{- end }}
{{- end }}
{{- if gt (len $subAgents) 0 }}{{- toYaml $subAgents -}}{{- end }}
{{- end -}}

{{/*
inst.platformRoutes — the portal stack's path-mode routing, one entry per component with a
`gatewayPath`, for agentgateway-policies' spec.platformRoutes.

Args: (list $top $components $gwPlatformPort $gwTLS $gwCertRef)
Returns: `routes: <yaml list>`, so the caller does (include ... | fromYaml).routes.

EXTRACTED FROM compositions.yaml 2026-11-14, for the same reason inst.subAgents was: that file
LISTs every CRD with `lookup` at its head, `helm template` DISABLES lookup, so it renders ZERO
composition objects and nothing inline in it can be exercised by any render. As a named helper it
is reachable from a probe chart with synthetic components and no cluster.

WHY NOW. Diego approved moving authn's path-mode prefix from /auth to /authn, because /auth in path
mode routes to authn (PathPrefix, rewrite on) and SWALLOWS the frontend's OIDC callback — the SPA
route /auth?kind=oidc, which authn answers with a 404 and the authorization code is lost. The claim
that moving the prefix fixes it rested on READING this code, and he approved it on condition the
render is PROVEN first. frontend asked for the sharper assertion: that /auth EXACT, WITH A QUERY,
is matched by NO authn route afterwards — not merely that /authn exists, which would pass while
leaving the bug.

The $gwPathMode gate stays at the CALL SITE. This helper answers "what routes do these components
imply"; whether path mode is on is the caller's question, and keeping it out means the helper can
be tested without faking that flag.
*/}}
{{- define "inst.platformRoutes" -}}
{{- $top := index . 0 -}}
{{- $components := index . 1 -}}
{{- $gwPlatformPort := index . 2 -}}
{{- $gwTLS := index . 3 -}}
{{- $gwCertRef := index . 4 -}}
{{- $routes := list }}
{{- range $d := $components }}
{{/* ENABLEMENT IS CHECKED FIRST, before any path computation, and that ordering is load-bearing.
     My first version computed the paths at the top of this loop, so the keycloakRealm derivation
     -- and its `fail` when relativePath is unset -- ran for EVERY pin carrying
     gatewayPathsFrom, enabled or not. On a cluster with features.keycloak false that would have
     failed the whole umbrella render over a component it does not install. It passed my first
     test only because a disabled component happens to be absent from $components, which is luck
     rather than design: this loop must not depend on that. Gating here makes a disabled
     component cost nothing and cannot fail. */}}
{{- if eq (include "inst.compEnabled" (list $top $d)) "true" }}
{{/* PATHS: one route per prefix. `gatewayPath` (string) stays the single-prefix form and renders
     BYTE-IDENTICALLY to before -- the four portal pins (authn /authn, snowplow /content, frontend /,
     krateo-sse-proxy /events) are untouched by this change, which is the control the PR asserts.
     `gatewayPaths` (list) is the multi-prefix form. Setting BOTH is a render failure rather than a
     silent precedence rule: a pin that disagrees with itself about its own routes is a bug, and
     picking one quietly is how the WRONG prefix ends up public.

     `gatewayPathsFrom` names a DERIVATION instead of literal paths. Keycloak needs one because its
     prefixes are built from two values that can both change:
       componentValues.keycloak.keycloak.http.relativePath          e.g. /keycloak
       componentValues.krateo-keycloak-realm.realm.name             default krateo
     Hard-coding /keycloak/realms/krateo/ in the pin would repeat exactly the coupling this PR also
     fixes for baseUrl/tokenEndpoint: rename the realm or move the relative path and the route
     silently stops matching, with every composition Ready. Deriving all three from the same two
     values makes them agree by CONSTRUCTION.

     Why a NAMED derivation and not a name match on `keycloak`: the pin declares which rule applies,
     so the coupling is greppable from the pins file and adding a second rule is an explicit act.
     keycloak-provider-kog measured the hazard this shape avoids: `/keycloak/realms/` alone would
     also expose the MASTER realm's sign-in and token endpoints to the internet, so admin passwords
     could be tried there even with /keycloak/admin unrouted. Only the one realm is exposed. */}}
{{- $paths := list }}
{{- if and $d.gatewayPath $d.gatewayPaths }}
{{- fail (printf "components[%s]: sets BOTH gatewayPath (%s) and gatewayPaths (%v). Use one: gatewayPath for a single prefix, gatewayPaths for several. Choosing between them silently would decide which prefix becomes PUBLIC." $d.name $d.gatewayPath $d.gatewayPaths) }}
{{- end }}
{{- if and $d.gatewayPathsFrom (or $d.gatewayPath $d.gatewayPaths) }}
{{- fail (printf "components[%s]: sets gatewayPathsFrom (%s) together with literal paths. A derived component must not also carry literals -- the literals would be dead and the derivation would look unused." $d.name $d.gatewayPathsFrom) }}
{{- end }}
{{- if $d.gatewayPaths }}
{{- $paths = $d.gatewayPaths }}
{{- else if $d.gatewayPath }}
{{- $paths = list $d.gatewayPath }}
{{- else if $d.gatewayPathsFrom }}
{{- if eq $d.gatewayPathsFrom "keycloakRealm" }}
{{- $cv := default dict $top.Values.componentValues }}
{{/* NORMALISED, because three different malformed shapes are reachable otherwise
     (keycloak-provider-kog, reviewing #968): Keycloak's OWN default http-relative-path is `/`,
     and someone may write `/keycloak/` with a trailing slash. Unnormalised those give
     `//realms/<realm>/` or `/keycloak//realms/<realm>/` as routes -- prefixes that can never
     match -- so the feature would be silently unreachable, which is the exact bug this change
     exists to fix. trimSuffix turns `/` into "" and `/keycloak/` into `/keycloak`. "" then takes
     the guard below, which is right: at the root, Keycloak's /resources/ would hijack that
     prefix from the portal SPA. */}}
{{- $rp := trimSuffix "/" (dig "keycloak" "keycloak" "http" "relativePath" "" $cv) }}
{{- if not $rp }}
{{- fail (printf "components[%s]: gatewayPathsFrom=keycloakRealm needs componentValues.keycloak.keycloak.http.relativePath, which is empty. On a gatewayMode=path cluster Keycloak MUST be served under a path prefix -- exposure.hosts is host-mode only, so it cannot be given a subdomain, and the issuer in its tokens must stay stable whatever path a request arrives on. Set it to e.g. /keycloak (no trailing slash). Without it there is no prefix to route and every OIDC login would 200 with the SPA instead." $d.name) }}
{{- end }}
{{- $realm := dig "krateo-keycloak-realm" "realm" "name" "krateo" $cv }}
{{- if not $realm }}{{- $realm = "krateo" }}{{- end }}
{{/* ONE realm, not the whole /realms/ tree, and the sign-in assets. /admin is deliberately absent:
     routing it would put the admin console on the public internet. Trailing slashes matter -- they
     make each prefix an element boundary, so /keycloak/realmsx and /keycloak/realms/krateox cannot
     match. No rewrite: Keycloak already serves under relativePath. */}}
{{- $paths = list (printf "%s/realms/%s/" $rp $realm) (printf "%s/resources/" $rp) }}
{{- else if eq $d.gatewayPathsFrom "accessRequestIntake" }}
{{/* IDENTITY-LIFECYCLE'S ACCESS-REQUEST INTAKE, and it is the OPPOSITE failure posture to
     keycloakRealm above. keycloakRealm FAILS when its input is missing, because a Keycloak that is
     enabled and unrouted is broken. This one must render NOTHING, silently, when the feature is
     off: an identity-lifecycle install without access requests is a legitimate configuration, and
     `if $paths` below already turns an empty list into no rule and no backend.

     Copying keycloakRealm's `fail` here would break every IL install that does not want the
     feature. Same mechanism, inverted posture -- which is exactly what gets copied wrong.

     WHY THE INTAKE NEEDS A ROUTE AT ALL (keycloak-provider-kog, measured on kc-roll057 and
     confirmed on krateo-057): IL's own intake.route renders only for a HOST-mode gateway -- "where
     the installer routes by path, it renders nothing". So on a path-mode cluster the intake
     Deployment runs and NOTHING routes to it: 057 had 26 HTTPRoutes, 27 rules, zero mentioning
     request-access. A browser's POST /request-access/api/... matched platform-frontend `/` and
     reached the SPA.

     ONE PREFIX COVERS THE WHOLE PUBLIC SURFACE. From internal/intake/server.go at IL 0.4.4 the
     intake serves exactly /request-access/api/v1/{requests,username-checks,confirmations,hubspot}.
     /healthz is probes-only and falls outside the prefix anyway. NO REWRITE: the intake serves
     under the prefix itself.

     NOT /request-access/confirm -- that page is NOT the intake's and not the frontend's either. It
     is portal's public-pages chart at /public/request-access-confirm, which is a separate pinned
     component. */}}
{{- $cv := default dict $top.Values.componentValues }}
{{- if eq (toString (dig "identity-lifecycle" "accessRequest" "intake" "enabled" false $cv)) "true" }}
{{- $paths = list "/request-access/api" }}
{{- end }}
{{- else }}
{{- fail (printf "components[%s]: gatewayPathsFrom=%s is not a derivation this chart knows. The ones this chart knows are keycloakRealm and accessRequestIntake." $d.name $d.gatewayPathsFrom) }}
{{- end }}
{{- end }}
{{- if $paths }}
{{- $backendName := include "inst.svcname" (list $top $d.svcMatch) }}
{{/* A DERIVED ROUTE FALLS BACK TO ITS svcMatch, NOT ITS COMPONENT NAME (keycloak-provider-kog).
     The generic fallback is $d.name, which for identity-lifecycle is the Service
     `identity-lifecycle` -- a name IL never renders. Mid-install, or wherever the lookup is
     vacuous, that produces a route pointing at a Service that will never exist: a dangling
     backend that looks configured. For a derived route the exact svcMatch is always the right
     target, so the route can only ever point at identity-lifecycle-intake. Whether this should
     become the GENERAL fallback belongs with the svcMatch exact-only work, not here. */}}
{{- if not $backendName }}
{{- if and $d.gatewayPathsFrom $d.svcMatch }}{{- $backendName = $d.svcMatch }}
{{- else }}{{- $backendName = $d.name }}{{- end }}
{{- end }}
{{/* THE CONTAINS-FALLBACK IS A REAL HAZARD FOR A DERIVED PUBLIC ROUTE, and it is already
     load-bearing elsewhere so it cannot simply be removed. inst.svcname is `$exact | default
     $contains`: an exact Service name wins, but when none exists it returns the FIRST Service whose
     name CONTAINS the svcMatch string.

     Measured on krateo-057: krateo-sse-proxy resolves THROUGH that fallback today (svcMatch
     `sse-proxy`, no such Service, resolves to `krateo-sse-proxy`), and five more are safe only
     because an exact Service happens to exist -- authn's `authn` also matches `authn-internal`,
     the TLS-only listener on 8090.

     For THIS route the sibling is `identity-lifecycle-intake-metrics` on port 9090
     (keycloak-provider-kog). A fallback onto it would publish a metrics port on a PUBLIC path and
     come up healthy, because the route would exist and the backend would answer. So a derived
     route refuses the fallback: exact or fail. The general fix to inst.svcname is a separate
     change in two releases. */}}
{{/* THE GUARD MUST NOT FIRE ON A VACUOUS LOOKUP. `lookup` returns nothing under `helm template`
     and `--dry-run=client`, so inst.svcname comes back EMPTY and line above falls back to
     $d.name -- which is not the svcMatch and would trip a naive `ne`. My first version did exactly
     that and broke all three tests plus every non-cluster render. So: fire only when the lookup
     RESOLVED something and that something is not the exact name. Empty means "no cluster to ask",
     which is not evidence of a wrong backend. */}}
{{- $resolved := include "inst.svcname" (list $top $d.svcMatch) }}
{{- if and $d.gatewayPathsFrom $resolved (ne $resolved $d.svcMatch) }}
{{- fail (printf "components[%s]: gatewayPathsFrom=%s resolved its backend to Service %q, which is NOT the exact svcMatch %q. inst.svcname fell back to a CONTAINS match. For a derived PUBLIC route that is refused: the sibling may be a metrics or internal listener (identity-lifecycle-intake-metrics:9090 is exactly this case), and the route would come up healthy on the wrong port. Create the exact Service, or correct svcMatch." $d.name $d.gatewayPathsFrom $resolved $d.svcMatch) }}
{{- end }}
{{/* Listener + ports: default to the shared platform-http:$gwPlatformPort listener and the peer's
     exposePort backend — the four portal pins (authn/snowplow/frontend/sse-proxy) carry NO
     gatewayListener/gatewayPort so these fallbacks reproduce today's route byte-identically. A
     component that needs its OWN listener (HyperDX: platform-hdx:3000, a Next.js root-asset app that
     can't be path-prefixed) sets gatewayListener + gatewayPort, and gatewayPort also becomes its
     backend port (it has no exposePort pin). */}}
{{/* Listener spec — normally the shared platform-http:$gwPlatformPort (or the component's own, e.g.
     HyperDX's platform-hdx:3000). Under path-mode TLS the DEFAULT (platform-http) routes move to the
     platform-https:443 HTTPS listener (protocol + Terminate tls → exposure.tls.certificateRef), so the
     whole single-origin portal is served over TLS.

     EVERY platform listener follows, not just the shared one. They all land on the platform Gateway,
     which the agentgateway controller gives ONE LoadBalancer Service — so they share a single public
     IP. Leaving a component with its OWN listener on plaintext while the portal moved to :443 served
     that component in the clear on the same public address as the HTTPS portal, and every template
     still rendered correctly because each listener was individually valid. That is how HyperDX ended
     up reachable over public HTTP on :3000: a Next.js root-asset app can't be path-prefixed, so it
     gets its own listener, and only the shared listener was being upgraded. A component listener
     keeps its own NAME and PORT and gains the same protocol + certificateRef — the certificate is
     for exposure.tls.host, which is valid on any port. agentgateway-policies now refuses a mixed
     posture outright, so this and that guard have to agree.

     Off (no exposure.tls) => byte-identical: every listener stays plaintext, the documented HTTP
     mode. */}}
{{- $lname := default "platform-http" $d.gatewayListener }}
{{- $lspec := dict "name" $lname "port" (int (default $gwPlatformPort $d.gatewayPort)) }}
{{- if $gwTLS }}
{{- if eq $lname "platform-http" }}
{{- $lspec = dict "name" "platform-https" "port" 443 "protocol" "HTTPS" "tls" (dict "certificateRef" $gwCertRef) }}
{{- else }}
{{- $lspec = dict "name" $lname "port" (int (default $gwPlatformPort $d.gatewayPort)) "protocol" "HTTPS" "tls" (dict "certificateRef" $gwCertRef) }}
{{- end }}
{{- end }}
{{- range $i, $p := $paths }}
{{/* NAME: a single-prefix component keeps its BARE name, so the existing four routes are
     byte-identical. Several prefixes get <name>-<index>, because two HTTPRoutes sharing a name
     would collide and agentgateway-policies requires them unique. */}}
{{- $rname := $d.name }}
{{- if gt (len $paths) 1 }}{{- $rname = printf "%s-%d" $d.name $i }}{{- end }}
{{- $route := dict
     "name" $rname
     "listener" $lspec
     "pathPrefix" $p
     "rewrite" (default false $d.gatewayRewrite)
     "backend" (dict "name" $backendName "port" (int (default $d.exposePort $d.gatewayPort)))
     "auth" (dict "mode" (default "public" $d.gatewayAuth)) }}
{{- $routes = append $routes $route }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
routes:
{{- if gt (len $routes) 0 }}
{{ toYaml $routes | indent 2 }}
{{- else }} []
{{- end }}
{{- end -}}
